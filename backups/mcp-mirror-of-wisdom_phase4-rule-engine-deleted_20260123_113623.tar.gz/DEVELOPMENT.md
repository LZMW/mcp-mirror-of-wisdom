# 开发指南

> 求知镜 MCP 的完整开发文档

---

## 📋 目录

1. [项目概述](#项目概述)
2. [架构设计](#架构设计)
3. [开发环境](#开发环境)
4. [测试指南](#测试指南)
5. [部署说明](#部署说明)
6. [Phase 2 规划](#phase-2-规划)
7. [常见问题](#常见问题)

---

## 项目概述

### 核心功能

求知镜 MCP 是一个基于 MCP 协议的服务器，根据任务描述动态生成专家角色提示词。

**Phase 1 MVP 特性**：
- ✅ 8 种预定义专家（技术、创意、商业、教育、写作、研究、哲学、通用）
- ✅ 基于关键词的规则引擎
- ✅ 支持多种 LLM 提供商
- ✅ Markdown 和 JSON 双格式输出
- ✅ 完整的输入验证

### 技术栈

- **语言**: Python 3.10+
- **框架**: FastMCP
- **验证**: Pydantic v2
- **配置**: python-dotenv
- **HTTP**: httpx

---

## 架构设计

### 系统分层

```
┌─────────────────────────────────────┐
│   MCP Server (server.py)            │  服务器层
├─────────────────────────────────────┤
│   Tools (consult_mirror.py)         │  工具层
├─────────────────────────────────────┤
│   Prompt Generator                  │  业务逻辑层
├─────────────────────────────────────┤
│   LLM Client                        │  LLM 抽象层
├─────────────────────────────────────┤
│   Config                            │  配置层
└─────────────────────────────────────┘
```

### 模块说明

#### config.py - 配置管理

**功能**：
- 加载和管理环境变量
- Pydantic 数据验证
- 全局配置实例

**核心类**：
- `MirrorConfig`: LLM 配置（提供商、API Key、模型等）
- `ServerConfig`: 服务器配置（日志、功能开关）
- `FeatureConfig`: 功能配置（会话、压缩）

#### llm_client.py - LLM 客户端

**功能**：
- 统一的 LLM 接口
- 支持 5 种提供商
- 自动重试和错误处理

**核心类**：
- `MirrorLLMClient`: 主客户端类
  - `_init_openai()`: OpenAI 初始化
  - `_init_anthropic()`: Anthropic 初始化
  - `_init_zhipu()`: 智谱 AI 初始化
  - `_init_gemini()`: Gemini 初始化
  - `_init_custom()`: 自定义 API 初始化

#### prompt_generator.py - 提示词生成器

**功能**：
- 规则引擎（关键词匹配）
- 8 个预定义专家库
- 提示词格式化

**核心类**：
- `PromptGenerator`: 生成器类
  - `analyze_task_type()`: 分析任务类型
  - `generate_expert_prompt()`: 生成专家提示词
  - `format_expert_prompt()`: 格式化输出

**专家库**：
```python
EXPERT_LIBRARY = {
    "technical": 技术专家,
    "creative": 创意设计师,
    "business": 商业战略顾问,
    "education": 教育专家,
    "writing": 写作顾问,
    "research": 研究分析师,
    "philosophy": 哲学思考者,
    "general": 通用助手
}
```

#### consult_mirror.py - MCP 工具

**功能**：
- MCP 工具实现
- 输入验证
- 错误处理

**核心类**：
- `ConsultMirrorInput`: Pydantic 输入模型
- `consult_mirror()`: 工具实现函数

#### server.py - 服务器入口

**功能**：
- FastMCP 初始化
- 工具注册
- 日志配置

---

## 开发环境

### 环境配置

```bash
# 1. 创建虚拟环境
python -m venv venv

# 2. 激活虚拟环境
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# 3. 安装依赖
pip install -e .

# 4. 配置环境变量
cp .env.example .env
# 编辑 .env
```

### 开发工具

**必需**：
- Python 3.10+
- pip

**推荐**：
- pytest（测试）
- ruff（代码检查）
- MCP Inspector（调试）

### IDE 配置

**VSCode**:
```json
{
  "python.defaultInterpreterPath": "./venv/bin/python",
  "python.linting.enabled": true,
  "python.formatting.provider": "black"
}
```

---

## 测试指南

### 运行测试

```bash
# 运行所有测试
pytest tests/ -v

# 运行基础测试
python tests/test_basic.py

# 运行特定测试
pytest tests/test_consult_mirror.py -v
```

### 测试覆盖

**单元测试**：
- `test_config.py`: 配置管理测试
- `test_llm_client.py`: LLM 客户端测试
- `test_prompt_generator.py`: 提示词生成器测试

**集成测试**：
- `test_consult_mirror.py`: 工具集成测试
- `test_server.py`: 服务器集成测试

### 使用 MCP Inspector

```bash
# 启动 Inspector
npx @modelcontextprotocol/inspector python -m mirror_of_wisdom.server

# 测试工具
1. 打开浏览器（http://localhost:5173）
2. 选择 consult_mirror 工具
3. 输入测试参数
4. 点击 "Call Tool"
5. 查看返回结果
```

---

## 部署说明

### 本地部署

```bash
# 1. 安装依赖
pip install -e .

# 2. 配置环境变量
cp .env.example .env

# 3. 运行服务器
python -m mirror_of_wisdom.server
```

### Claude Desktop 集成

编辑 Claude Desktop 配置文件：

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
**Mac/Linux**: `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "mirror-of-wisdom": {
      "command": "python",
      "args": ["-m", "mirror_of_wisdom.server"],
      "env": {
        "MIRROR_PROVIDER": "openai",
        "MIRROR_API_KEY": "your-api-key",
        "MIRROR_MODEL": "gpt-4o-mini"
      }
    }
  }
}
```

### Docker 部署（可选）

```dockerfile
FROM python:3.10-slim

WORKDIR /app
COPY . /app

RUN pip install -e .

ENV MIRROR_PROVIDER=openai
ENV MIRROR_MODEL=gpt-4o-mini

CMD ["python", "-m", "mirror_of_wisdom.server"]
```

---

## Phase 2 规划

### 目标功能

- ✅ 多轮对话（in_dialogue 阶段）
- ✅ 角色切换（change_reflection 工具）
- ✅ LLM 动态生成专家
- ✅ 会话状态管理
- ✅ 配置热重载

### 实现优先级

**Week 1-2**: 会话管理
- Session Manager 实现
- 会话 ID 生成和追踪
- 对话历史维护

**Week 3-4**: 角色切换
- change_reflection 工具实现
- 上下文延续机制
- 状态验证

**Week 5-6**: LLM 生成
- 集成 LLM 动态生成
- 质量检查机制
- 迭代优化

### 依赖关系

```
Phase 1 (当前)
    ↓
会话管理 (Phase 2.1)
    ↓
角色切换 (Phase 2.2)
    ↓
LLM 生成 (Phase 2.3)
```

---

## 常见问题

### 开发相关

**Q: 如何添加新的专家？**

编辑 `prompt_generator.py`，在 `EXPERT_LIBRARY` 中添加：

```python
"new_expert": {
    "name": "新专家名称",
    "keywords": ["关键词1", "关键词2"],
    "system_prompt": """专家提示词内容"""
}
```

**Q: 如何支持新的 LLM 提供商？**

1. 在 `config.py` 添加新的 provider 值
2. 在 `llm_client.py` 实现 `_init_new_provider()` 方法
3. 在 `async def chat()` 中添加对应的处理分支

**Q: 如何调试 MCP 工具？**

```bash
# 使用 MCP Inspector
npx @modelcontextprotocol/inspector python -m mirror_of_wisdom.server

# 添加日志
logger.setLevel(logging.DEBUG)
```

### 部署相关

**Q: 如何更改端口？**

编辑 `server.py`：

```python
if __name__ == "__main__":
    mcp.run(port=8001)  # 更改端口
```

**Q: 如何启用 CORS？**

FastMCP 默认使用 stdio 传输，不需要 CORS。

如果是 HTTP 传输，配置反向代理（如 nginx）。

---

## 贡献指南

### 代码风格

- 遵循 PEP 8
- 使用类型提示
- 添加 docstring
- 保持代码简洁

### 提交流程

1. Fork 项目
2. 创建特性分支
3. 提交 Pull Request
4. 等待 Code Review

---

## 相关文档

- **快速开始**: [QUICKSTART.md](QUICKSTART.md)
- **设计文档**: `docs/` 目录
- **MCP 官方文档**: https://modelcontextprotocol.io

---

**最后更新**: 2025-01-22
**版本**: v0.1.0
