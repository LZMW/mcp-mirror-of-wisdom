# 快速开始指南

> 5 分钟上手求知镜 MCP

---

## 📋 前置要求

- ✅ Python 3.10 或更高版本
- ✅ pip（Python 包管理器）
- ✅ LLM API Key（OpenAI 格式或兼容 API）

---

## 🚀 5 分钟快速上手

### Step 1: 配置环境变量（1 分钟）

```bash
# 进入项目目录
cd mcp-mirror-of-wisdom

# 复制配置模板
cp .env.example .env

# 编辑 .env 文件，填入你的 API Key
# Windows: notepad .env
# Linux/Mac: nano .env
```

**.env 文件示例**：
```bash
MIRROR_PROVIDER=openai
MIRROR_API_KEY=sk-your-api-key-here
MIRROR_MODEL=gpt-4o-mini
```

### Step 2: 安装依赖（2 分钟）

```bash
# 创建虚拟环境（推荐）
python -m venv venv

# 激活虚拟环境
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# 安装依赖
pip install -e .
```

### Step 3: 运行测试（1 分钟）

```bash
# 运行基础测试
python tests/test_basic.py
```

**预期输出**：
```
============================================================
求知镜 MCP - 基础测试
============================================================

测试 1: 提示词生成器
============================================================

【测试 1】技术问题
任务: 我需要优化我的 Python 代码性能...
✓ 成功
  - 任务类型: technical
  - 专家名称: 技术专家
  - 生成方法: rule_based

...
```

### Step 4: 启动服务器（1 分钟）

```bash
# 启动 MCP 服务器
python -m mirror_of_wisdom.server
```

**预期输出**：
```
INFO - 启动 Mirror of Wisdom MCP v0.1.0
INFO - 日志级别: INFO
INFO - 质量检查: 启用
INFO - 角色切换: 启用
```

---

## 🧪 使用 MCP Inspector 测试（推荐）

### 什么是 MCP Inspector？

MCP Inspector 是一个 Web UI 工具，用于测试 MCP 服务器。

### 启动步骤

```bash
# 安装 Node.js（如果还没有）
# 然后运行：
npx @modelcontextprotocol/inspector python -m mirror_of_wisdom.server
```

### 使用步骤

1. **浏览器自动打开**（通常是 http://localhost:5173）
2. **查看工具列表** - 应该能看到 `consult_mirror`
3. **点击工具** - 查看输入参数
4. **输入测试任务**：
   ```json
   {
     "task_description": "我需要设计一个儿童教育 App 的主角形象",
     "response_format": "markdown",
     "stage": "generate_role"
   }
   ```
5. **点击 "Call Tool"** - 查看返回结果

---

## 📝 测试用例

### 用例 1: 技术问题

```json
{
  "task_description": "我需要优化 Python 代码性能，特别是数据库查询部分"
}
```

**预期**: 返回技术专家提示词

### 用例 2: 创意设计

```json
{
  "task_description": "为一个儿童教育 App 设计主角形象，3-6岁目标用户"
}
```

**预期**: 返回创意设计师提示词

### 用例 3: 商业规划

```json
{
  "task_description": "帮我制定一个电商网站的 Q1 市场推广计划",
  "response_format": "json"
}
```

**预期**: 返回 JSON 格式的商业战略顾问信息

### 用例 4: 边界测试

```json
{
  "task_description": "如何做红烧肉？"
}
```

**预期**: 返回通用助手提示词（不崩溃）

---

## ⚠️ 常见问题

### Q1: "API 密钥不能为空"

**原因**: `.env` 文件未配置或配置错误

**解决**:
```bash
# 检查 .env 文件是否存在
cat .env

# 确认 API Key 已填写
grep MIRROR_API_KEY .env
```

### Q2: "不支持的 AI 提供商"

**原因**: `MIRROR_PROVIDER` 值错误

**解决**: 确保值为以下之一：
- `openai`
- `anthropic`
- `zhipu`
- `gemini`
- `custom`

### Q3: "模块未找到"

**原因**: 依赖未安装

**解决**:
```bash
# 重新安装依赖
pip install -e .

# 验证安装
python -c "import mirror_of_wisdom; print('OK')"
```

### Q4: MCP Inspector 连接失败

**原因**: 端口被占用或服务器未启动

**解决**:
```bash
# 检查服务器是否启动
python -m mirror_of_wisdom.server

# 检查端口占用（Windows）
netstat -ano | findstr :8000

# 更换端口（在 server.py 中修改）
```

---

## 🎯 下一步

测试成功后，你可以：

1. **集成到 Claude Desktop**
   - 配置 Claude Desktop 的 MCP 设置
   - 在对话中直接使用求知镜

2. **阅读开发文档**
   - 查看 [DEVELOPMENT.md](DEVELOPMENT.md)
   - 了解架构设计和扩展方法

3. **参与贡献**
   - 提交 Issue
   - 贡献代码

---

## 📚 更多资源

- **项目介绍**: [README.md](README.md)
- **开发指南**: [DEVELOPMENT.md](DEVELOPMENT.md)
- **设计文档**: `docs/` 目录
- **MCP 官方文档**: https://modelcontextprotocol.io

---

**遇到问题？** 查看 [DEVELOPMENT.md](DEVELOPMENT.md) 的常见问题章节
