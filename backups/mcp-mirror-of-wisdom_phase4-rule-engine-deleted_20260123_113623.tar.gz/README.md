# 求知镜 MCP (Mirror of Wisdom)

> **本地 AI 的神奇道具** - 根据任务需求动态生成专家角色提示词

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![MCP](https://img.shields.io/badge/MCP-compatible-green.svg)](https://modelcontextprotocol.io/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-0.2.0-brightgreen.svg)](https://github.com/your-org/mcp-mirror-of-wisdom)

---

## 🌟 项目简介

求知镜 MCP 是一个基于 MCP (Model Context Protocol) 的服务器，可以根据用户指定的专家类型，快速生成专业的专家角色提示词。

### 核心特性

- 🎭 **8 种预定义专家** - 技术、创意、商业、教育、写作、研究、哲学、通用
- 🚀 **零成本运行** - 不依赖 LLM API，响应快速（< 10ms）
- 📝 **双格式输出** - Markdown（人类可读）和 JSON（机器可读）
- 🎯 **用户可控** - 直接指定专家类型，结果可预期
- 🛡️ **输入验证** - Pydantic v2 数据验证
- ⚡ **即开即用** - 5 分钟快速上手

---

## 🚀 快速开始

### 安装

```bash
# 克隆项目
git clone https://github.com/your-org/mcp-mirror-of-wisdom.git
cd mcp-mirror-of-wisdom

# 安装依赖
pip install -e .

# 配置环境变量
cp .env.example .env
```

### 运行

```bash
# 启动服务器
python -m mirror_of_wisdom.server

# 或使用 MCP Inspector 测试
npx @modelcontextprotocol/inspector python -m mirror_of_wisdom.server
```

### 使用

```json
{
  "expert_type": "technical",
  "task_description": "优化数据库查询性能",
  "context": "用户量10万，需要高并发支持",
  "requirements": "使用开源方案，降低成本"
}
```

---

## 💡 使用场景

```
💡 技术架构设计
   → expert_type: "technical"
   → 返回: 技术专家角色提示词

🎨 创意设计
   → expert_type: "creative"
   → 返回: 创意设计师角色提示词

📈 商业规划
   → expert_type: "business"
   → 返回: 商业战略顾问角色提示词

📚 学习指导
   → expert_type: "education"
   → 返回: 教育专家角色提示词
```

---

## 📖 详细文档

### 用户文档

- **[QUICKSTART.md](QUICKSTART.md)** - 5分钟快速上手指南
- **[使用示例](README.md#使用示例)** - 常见使用场景

### 开发文档

- **[DEVELOPMENT.md](DEVELOPMENT.md)** - 完整开发指南
- **[说明文档.md](说明文档.md)** - 项目全生命周期文档

### 工作流文档

- **[ALIGNMENT](docs/求知镜MCP/ALIGNMENT_项目初始化.md)** - 需求对齐
- **[DESIGN](docs/求知镜MCP/DESIGN_架构设计.md)** - 架构设计
- **[TASK](docs/求知镜MCP/TASK_实施计划.md)** - 实施计划
- **[ACCEPTANCE](docs/求知镜MCP/ACCEPTANCE_Phase1.md)** - 验收报告
- **[FINAL](docs/求知镜MCP/FINAL_Phase1总结.md)** - 项目总结

---

## 🏗️ 项目结构

```
mcp-mirror-of-wisdom/
├── 说明文档.md              # 项目主文档
├── README.md               # 本文件
├── QUICKSTART.md           # 快速开始
├── DEVELOPMENT.md          # 开发指南
├── pyproject.toml          # 项目配置
│
├── src/
│   ├── mirror_of_wisdom/   # 核心包
│   │   ├── config.py       # 配置管理
│   │   ├── prompt_generator.py  # 专家库
│   │   └── llm_client.py   # LLM 客户端（备用）
│   ├── tools/              # MCP 工具
│   │   └── consult_mirror.py  # 核心工具 (v2)
│   └── server.py           # 服务器入口
│
├── tests/                  # 测试
│   ├── test_basic.py
│   ├── test_consult_mirror.py
│   └── test_v2_simplified.py
│
└── docs/                   # 文档
    ├── 求知镜MCP/          # 工作流文档
    ├── test-phase1/        # 测试文档
    └── archive/            # 历史归档
```

---

## 🎯 专家类型

| 类型 | 名称 | 适用场景 |
|------|------|---------|
| `technical` | 技术专家 | 编程、架构、算法、调试 |
| `creative` | 创意设计师 | UI/UX、视觉设计、品牌 |
| `business` | 商业战略顾问 | 市场分析、商业模式、战略 |
| `education` | 教育专家 | 学习指导、课程设计 |
| `writing` | 写作顾问 | 文案、内容创作、邮件 |
| `research` | 研究分析师 | 数据分析、市场调研 |
| `philosophy` | 哲学思考者 | 伦理探讨、价值判断 |
| `general` | 通用助手 | 通用问题 |

---

## 📊 项目状态

### Phase 1: MVP (已完成 ✅)

**版本**: v0.2.0 (简化设计 v2)

**功能**：
- ✅ 8 种预定义专家角色
- ✅ 用户直接指定专家类型
- ✅ 双格式输出（Markdown/JSON）
- ✅ 可选参数（context、requirements）
- ✅ MCP 工具集成
- ✅ 100% 测试覆盖率

**性能**：
- 响应时间: < 10ms
- 内存占用: < 50MB
- 零 API 成本

### Phase 2: LLM 智能集成 (已完成 ✅)

**版本**: v0.3.0 (混合模式)

**功能**：
- ✅ LLM 动态生成专家提示词
- ✅ 混合运行模式（规则引擎 + LLM 生成）
- ✅ 智能任务分析（置信度评分）
- ✅ 自动回退机制（LLM 失败时）
- ✅ 批量验证通过（20/20 测试，100% 成功率）

**性能**：
- 规则引擎: < 10ms
- LLM 生成: 约 8-15 秒（取决于网络和 API）
- 平均置信度: 0.985

### Phase 3: 生产优化 (规划中)

---

## 🔗 相关链接

- **[MCP 官方文档](https://modelcontextprotocol.io)**
- **[FastMCP 框架](https://github.com/jlowin/fastmcp)**
- **[Claude Desktop](https://claude.ai/download)**

---

## 📝 更新日志

### v0.3.0 (2025-01-22)

**重大更新**：Phase 2 LLM 智能集成
- 🧠 新增 LLM 动态生成模式
- 🔄 实现混合运行模式（Strangler Fig 策略）
- ⚡ 智能任务分析与置信度评分
- 🛡️ 完善的错误处理与自动回退
- ✅ 批量验证通过（20/20，100% 成功率）
- 🔧 修复 Prompt 模板 JSON 解析问题
- 📝 更新架构文档和验收报告

### v0.2.0 (2025-01-22)

**重大更新**：
- ✨ 简化设计 v2：用户直接指定专家类型
- ✂️ 移除识别环节，提高效率
- ⚡ 响应时间优化：从 > 100ms 降至 < 10ms
- 🔧 新增可选参数：context、requirements
- ✅ 测试覆盖率提升至 100%
- 📝 完善工作流文档

### v0.1.0 (2025-01-21)

**初始版本**：
- ✨ 基础功能实现
- 📦 8 种专家类型
- 🔌 MCP 工具集成

---

## 🤝 贡献

欢迎贡献！请查看 [DEVELOPMENT.md](DEVELOPMENT.md) 了解开发指南。

---

## 📄 许可证

MIT License

---

## 💬 联系方式

- **Issues**: [GitHub Issues](https://github.com/your-org/mcp-mirror-of-wisdom/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/mcp-mirror-of-wisdom/discussions)

---

**需要帮助？** 查看 [QUICKSTART.md](QUICKSTART.md) 或 [DEVELOPMENT.md](DEVELOPMENT.md)
