# ALIGNMENT - Phase 4 架构重构

> 阶段1: Align (对齐阶段)
> 创建时间: 2025-01-23
> 项目: 求知镜 MCP Phase 4
> 基于: Phase 3 v0.4.0
> 优先级: 🔴 **最高优先级 - 核心架构修正**

---

## 1. 项目背景

### Phase 1-3 成果回顾

**已完成功能**：
- ✅ Phase 1: 8种预定义专家、规则引擎、MCP工具集成
- ✅ Phase 2: SessionManager会话管理、元提示词集成、两阶段流程
- ✅ Phase 3: 性能优化（缓存、异步、熔断器、监控）

**当前技术基础**：
- ✅ `SessionManager` (session_manager.py) - 会话状态管理
- ✅ `PromptGenerator` (prompt_generator.py) - 专家提示词生成
- ✅ `LLMClient` (llm_client.py) - LLM API调用（支持system prompt）
- ✅ 性能优化模块（缓存、监控、熔断器）

### 核心架构问题（Phase 4 需解决）

**用户指出的问题**：
> "本地ai对求知镜发出需求，求知镜生成这个需求对应的专家提示词到求知镜扮演这个专家的这个过程是不对本地ai展示的"

**当前错误实现**：
```
本地AI → consult_mirror(expert_type, task)
求知镜 → 生成专家提示词
求知镜 → ❌ 返回提示词给本地AI
本地AI → ❌ 上下文被长提示词污染
```

**正确架构（双层设计）**：
```
【表层】求知镜 = 神奇的联系工具（对外展现）
【里层】1. 专家提示词生成器
       2. 装载后扮演对话机制（API system prompt）

本地AI → 调用工具
求知镜 → 内部生成专家提示词（❌ 不返回）
求知镜 → 将提示词设置为 API 的 system prompt
求知镜 → 以专家AI身份 → 发起首次对话
本地AI → 接收专家回复（✅ 零污染）
```

---

## 2. Phase 4 核心目标

### 主要目标

修正核心架构理解问题，实现**双层架构设计**：

1. **专家内部化机制**：
   - 专家提示词生成后不返回给本地AI
   - 作为 LLM API 的 `role="system"` 消息内部使用
   - 求知镜以专家AI身份与本地AI对话

2. **多轮对话优化**：
   - 专家发起信息粒度对齐（主动询问细节）
   - 基于system prompt保持专家角色一致性
   - 会话结束自动卸载专家角色

3. **零上下文污染**：
   - 本地AI只接收专家回复内容
   - System prompt 永远在求知镜内部
   - 本地AI上下文窗口保持清洁

### 核心价值

- 🎯 **架构正确性**：修正核心设计误区
- 🧹 **零污染**：本地AI上下文不受影响
- 💬 **自然对话**：本地AI感觉"联系"到了真实专家
- 🔄 **状态管理**：清晰的会话生命周期

---

## 3. 需求理解

### 3.1 双层架构设计

**表层（对外展现）**：
- 求知镜定位为"神奇的联系工具"
- 功能：帮助本地AI联系各行各业顶尖专家

**里层（内部机制）**：
- **第一部分**：专家提示词生成器
  - 根据需求生成专家提示词
  - 提示词仅供内部使用

- **第二部分**：装载后扮演对话机制
  - **核心概念**：扮演 = 设置 API 的 system prompt
  - 将专家提示词设置为 LLM API 调用的 `role="system"` 消息
  - 求知镜以专家AI身份运行
  - 保持专家system prompt直到问题解决

### 3.2 技术实现要点

**System Prompt 机制**：
```python
# LLM API 调用示例
messages = [
    {
        "role": "system",  # ← Expert system prompt（不返回给本地AI）
        "content": "你是资深技术专家，精通系统架构..."
    },
    {
        "role": "user",
        "content": "如何优化数据库？"
    }
]

response = await llm_client.generate(messages=messages)
# ✅ 只返回 assistant 消息，system prompt 在内部
```

**关键特性**：
- System prompt 只在求知镜内部，不返回给本地AI
- 每次LLM调用都包含 expert system prompt
- 专家角色一致性通过 system prompt 保证

### 3.3 会话生命周期

```
1. 本地AI发起联系请求
   ↓
2. 求知镜内部生成专家提示词（不返回）
   ↓
3. 将专家提示词设置为 system prompt
   ↓
4. 求知镜（以专家身份）发起信息粒度对齐
   ↓
5. 多轮对话解决问题
   ↓
6. 会话结束，卸载 expert system prompt
   ↓
7. 恢复默认联系工具身份
```

---

## 4. 功能需求

### 4.1 工具接口调整

**当前工具**（expert_session.py）：
1. `create_expert_session` - 创建会话并生成专家提示词
2. `chat_with_expert` - 与专家多轮对话
3. `close_session` - 关闭会话

**需要调整的行为**：

#### create_expert_session
**当前行为**：
- 返回会话ID和创建确认
- 专家提示词存储在SessionManager

**修改为**：
- 内部生成专家提示词（不返回）
- 立即调用LLM生成专家的首次回复（信息粒度对齐）
- 返回会话ID + 专家首次回复

**伪代码**：
```python
async def create_expert_session(requirement):
    # 1. 生成专家提示词（内部）
    expert_prompt = await generate_expert_prompt(requirement)

    # 2. 创建会话（存储expert prompt）
    session_id = await session_manager.create_session(
        system_prompt=expert_prompt
    )

    # 3. 生成专家首次回复（信息粒度对齐）
    first_reply = await llm_client.generate([
        {"role": "system", "content": expert_prompt},
        {"role": "user", "content": f"用户需求：{requirement}\n请主动询问细节以对齐信息粒度"}
    ])

    # 4. 返回会话ID + 专家首次回复
    return {
        "session_id": session_id,
        "expert_reply": first_reply  # ✅ 只返回回复，不返回system prompt
    }
```

#### chat_with_expert
**当前行为**（已正确）：
- 使用 session.system_prompt 作为 system 消息
- 返回专家AI的回复

**确认**：此工具已正确实现，无需修改

#### close_session
**当前行为**：
- 关闭会话，清理资源

**可选增强**：
- 提供会话总结
- 明确提示专家角色已卸载

### 4.2 consult_mirror.py 处理

**选项A**：标记为 deprecated
```python
async def consult_mirror(params):
    """
    ⚠️ **已弃用**：请使用 create_expert_session + chat_with_expert

    此工具仅用于向后兼容，新项目请勿使用。
    """
    # 保留原有行为
```

**选项B**（推荐）：重命名为 start_expert_session
- 修改行为与 create_expert_session 一致
- 提供更清晰的语义

### 4.3 信息粒度对齐

**在专家首次回复中实现**：
- 主动询问关键细节（根据专家类型定制）
- 引导本地AI提供完整上下文
- 确保专家建议的针对性

**示例**：
```
[本地AI]：优化数据库
[求知镜-技术专家]：我是技术专家。请提供：
  1. 数据库类型（MySQL/PostgreSQL/MongoDB？）
  2. 数据规模（百万级/千万级？）
  3. 性能瓶颈（查询慢/写入慢/存储？）
  4. 优化目标（响应时间/吞吐量/成本？）
```

---

## 5. 边界与约束

### 5.1 任务边界

**必须实现**：
- ✅ Expert system prompt 内部化（不返回给本地AI）
- ✅ 求知镜以专家AI身份多轮对话
- ✅ 信息粒度对齐机制
- ✅ 会话生命周期管理

**必须保留**：
- ✅ Phase 1-3 核心功能（专家库、会话管理、性能优化）
- ✅ MCP 协议兼容性
- ✅ 现有测试覆盖率

**不能做**：
- ❌ 不能将专家提示词返回给本地AI
- ❌ 不能破坏现有会话管理机制
- ❌ 不能引入新的外部依赖

### 5.2 技术约束

1. **LLM API 约束**：
   - System prompt 通过 `role="system"` 设置
   - System prompt 不返回给客户端（由API保证）

2. **并发约束**：
   - 使用 SessionManager 的锁机制
   - 确保 system prompt 切换的原子性

3. **性能约束**：
   - 响应时间 < 100ms（不含LLM调用）
   - 缓存机制复用 Phase 3 实现

### 5.3 非功能性需求

| 需求 | 指标 | 说明 |
|------|------|------|
| 性能 | < 100ms | 工具调用响应时间（不含LLM） |
| 可靠性 | 99.9% | 会话状态持久化 |
| 可维护性 | 代码清晰 | 注释完善，模块化设计 |
| 可测试性 | > 80% | 单元测试覆盖率 |

---

## 6. 实施策略

### 6.1 方案选择（混合模式）

**不创建新的 ExpertRolePlayer 类**，而是在现有架构上调整：

**理由**：
1. SessionManager 已有 system_prompt 字段
2. LLMClient 已支持 system prompt 机制
3. 最小化代码变更，最大化复用

**核心修改点**：
1. 调整 `create_expert_session` 返回专家首次回复
2. 确认 `chat_with_expert` 正确使用 system prompt（已实现）
3. 处理 `consult_mirror`（重命名或标记deprecated）

### 6.2 实施优先级

**P0 任务**（核心）：
1. ✅ 修改 `create_expert_session` 行为
   - 生成专家首次回复
   - 返回 session_id + expert_reply

2. ✅ 验证 `chat_with_expert` system prompt 机制
   - 确认已正确实现
   - 如有问题，立即修复

**P1 任务**（重要）：
3. ✅ 处理 `consult_mirror`
   - 重命名为 `start_expert_session`
   - 或标记为 deprecated

4. ✅ 更新 server.py 工具注册
   - 反映新的工具名称和行为

**P2 任务**（优化）：
5. ✅ 增强 `close_session`
   - 提供会话总结
   - 明确提示角色卸载

6. ✅ 编写迁移指南
   - 新旧接口对比
   - 使用示例

**P3 任务**（文档）：
7. ✅ 更新所有相关文档
8. ✅ 编写单元测试和集成测试

---

## 7. 验收标准

### 7.1 功能验收

**核心功能**：
- ✅ `create_expert_session` 返回专家首次回复
- ✅ 专家回复基于 expert system prompt
- ✅ System prompt 未返回给本地AI（验证工具输出）
- ✅ 多轮对话保持专家角色一致性

**信息粒度对齐**：
- ✅ 专家首次回复主动询问细节
- ✅ 问题根据专家类型定制

**会话管理**：
- ✅ 会话状态正确维护
- ✅ 会话结束正确卸载专家角色

### 7.2 质量验收

**代码质量**：
- ✅ 代码风格符合项目规范
- ✅ 函数注释完整
- ✅ 错误处理完善

**测试覆盖**：
- ✅ 单元测试覆盖率 > 80%
- ✅ 集成测试通过
- ✅ 端到端测试验证完整流程

**文档完整性**：
- ✅ 架构文档更新
- ✅ API文档更新
- ✅ 迁移指南提供

### 7.3 性能验收

- ✅ 工具调用响应时间 < 100ms（不含LLM）
- ✅ Phase 3 性能优化仍然有效
- ✅ 缓存命中率 > 70%

---

## 8. 风险评估

### 8.1 技术风险

| 风险 | 影响 | 可能性 | 缓解措施 |
|------|------|--------|----------|
| System prompt机制实现错误 | 🔴 严重 | 🟢 低 | 严格参考ARCHITECTURE_CLARIFICATION.md |
| 并发状态下不一致 | 🟡 中等 | 🟡 中等 | 使用SessionManager锁机制 |
| 现有功能被破坏 | 🔴 严重 | 🟢 低 | 充分测试，渐进式部署 |

### 8.2 业务风险

| 风险 | 影响 | 可能性 | 缓解措施 |
|------|------|--------|----------|
| 用户不理解新接口 | 🟡 中等 | 🟡 中等 | 提供清晰文档和示例 |
| 向后兼容性问题 | 🟡 中等 | 🟢 低 | 标记deprecated，保留旧接口 |
| 迁移成本高 | 🟢 低 | 🟢 低 | 提供自动化迁移脚本 |

---

## 9. 相关文档

### 核心参考

1. **架构澄清**（最高优先级）
   - `docs/求知镜MCP/ARCHITECTURE_CLARIFICATION.md`
   - 详细说明双层架构设计和API实现

2. **Phase 3 验收报告**
   - `docs/求知镜MCP/ACCEPTANCE_Phase3.md`
   - 当前功能基线

3. **功能与流程分析**
   - `docs/求知镜MCP/功能与流程分析报告.md`
   - 现有流程说明

### 代码参考

1. `src/tools/expert_session.py` - 需要调整的核心工具
2. `src/mirror_of_wisdom/session_manager.py` - 会话管理
3. `src/mirror_of_wisdom/llm_client.py` - LLM调用
4. `src/mirror_of_wisdom/prompt_generator.py` - 提示词生成

---

## 10. 下一步

**Align 阶段待确认**：
- ✅ 需求边界已明确
- ✅ 架构方案已确定
- ✅ 实施路径已规划

**等待用户确认**：
- 是否同意混合模式方案（最小化变更）？
- 是否同意 P0-P3 优先级排序？
- 是否有其他需求或约束？

**确认后进入**：
- Architect 阶段：设计详细架构和接口
- 创建 DESIGN_Phase4.md

---

**文档创建人**：AI 开发团队
**创建时间**：2025-01-23
**状态**：✅ Align 阶段完成，等待用户确认
**优先级**：🔴 **最高** - 核心架构修正
