# 架构澄清：双层架构设计（联系工具 + 生成扮演机制）

> **创建时间**：2025-01-23
> **问题级别**：🔴 **最高优先级 - 核心架构重新设计**
> **状态**：✅ **架构理解已明确，待实施**

---

## 0. 架构理解澄清（已明确）

### 用户最终澄清（2025-01-23）

**用户原话**：
> "本地AI → 求知镜(联系工具) → 专家(某个服务/角色)
> 求知镜的表层（也就是功能描述）对本地ai来说一种神奇的联系工具，可以联系各行各业最顶尖的专家。
> 求知镜的里层（也就是内部机制由两部分组成，其实就是专家提示词生成器，生成提示词之后在装载后扮演对话机制）"

### 双层架构设计

#### 📱 表层（对外展现 - 本地AI看到的）

求知镜是一个**神奇的联系工具**：
- 定位：可以联系各行各业最顶尖的专家
- 功能：作为本地AI与专家之间的桥梁
- 体验：本地AI → 求知镜 → 专家

#### ⚙️ 里层（内部机制 - 不对外展示）

由两部分组成：

**第一部分：专家提示词生成器**
- 根据本地AI的需求生成对应的专家提示词
- 提示词**仅供内部使用**，不返回给本地AI

**第二部分：装载后扮演对话机制**
- **核心概念**：每个AI都可以被设置一段"根提示词"
- **扮演机制**：把专家提示词当作**根提示词加载**
- 装载后，求知镜这个AI本身就以专家身份运行
- 保持专家根提示词直到问题解决

---

### 架构关系图

```
┌─────────────────────────────────────────────────────────────┐
│                    求知镜（双层架构）                          │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  📱 表层（对外）              ⚙️ 里层（内部）                   │
│  ┌──────────────┐          ┌──────────────────────────┐     │
│  │ 神奇的联系工具 │          │ 1. 专家提示词生成器        │     │
│  │              │          │    - 生成专家提示词        │     │
│  │ "可以联系     │   ───→   │    - 提示词不返回给本地AI  │     │
│  │  各行各业     │          │                            │     │
│  │  顶尖专家"    │          │ 2. 装载后扮演对话机制      │     │
│  │              │          │    - 装载专家提示词        │     │
│  └──────┬───────┘          │    - 扮演专家角色对话      │     │
│         │                 │    - 保持角色到问题解决     │     │
│         │                 └──────────────────────────┘     │
│         │                                                   │
└─────────┼───────────────────────────────────────────────────┘
          │
          ↓
┌─────────────────────────────────────────────────────────────┐
│                      工作流程                                 │
└─────────────────────────────────────────────────────────────┘

本地AI → 求知镜 → 专家（被求知镜装载和扮演）
```

---

### 关键理解要点

| 维度 | 说明 |
|------|------|
| **定位** | 求知镜是**联系工具**，可以被装载专家根提示词 |
| **体验** | 本地AI感觉通过求知镜"联系"到了专家 |
| **机制** | 生成专家提示词 → **作为根提示词加载** → 求知镜以专家身份运行 |
| **隔离** | 专家提示词只在求知镜内部作为根提示词，不污染本地AI上下文 |
| **核心概念** | **扮演 = 加载根提示词**，求知镜本身就是AI，可被设置不同根提示词 |

---

## 1. 问题识别

### 1.1 用户最初指出的核心问题

**用户原话**：
> "我的想法是本地ai对求知镜发出需求，求知镜生成这个需求对应的专家提示词到求知镜扮演这个专家的这个过程是不对本地ai展示的，而当求知镜已经扮演这个专家的时候才会发送一条消息给本地ai,询问本地ai详细需求，与本地ai进行信息颗粒度对齐后再，根据本地ai的具体要求（工作任务之类的）进行回复，直至问题解决，中断使用。"

**基于用户最新澄清的重新理解**:
- 用户最初说的"求知镜扮演专家"可能是指求知镜**协助联系**专家
- 核心问题仍然是:专家提示词不应该返回给本地AI
- ⚠️ **但具体架构需要等待用户进一步澄清**

---

## 2. 当前实现（❌ 错误）

### 2.1 当前工作流程

```
┌─────────────────────────────────────────────────────────────┐
│                    当前错误的工作流程                          │
└─────────────────────────────────────────────────────────────┘

本地AI
  ↓ 调用 consult_mirror 工具
  ↓ 参数: expert_type, task_description
  ↓
求知镜 MCP
  ↓ 生成专家提示词
  ↓ ❌ 返回提示词给本地AI
  ↓
本地AI
  ↓ ❌ 将长提示词加入自己的上下文窗口
  ↓ ❌ 上下文污染！
  ↓
本地AI使用被污染的上下文继续工作
```

### 2.2 问题分析

| 问题 | 影响 | 严重性 |
|------|------|--------|
| **上下文污染** | 长提示词占用本地AI的上下文窗口 | 🔴 严重 |
| **角色混淆** | 本地AI不知道应该把求知镜当作专家 | 🔴 严重 |
| **信息粒度不对齐** | 没有明确的需求确认和细化阶段 | 🟡 中等 |
| **缺乏多轮对话** | 一次性返回提示词，无法持续交互 | 🟡 中等 |

---

## 3. 正确架构（✅ 双层架构）

### 3.1 正确工作流程

```
┌─────────────────────────────────────────────────────────────────┐
│                  正确的工作流程（双层架构）                        │
└─────────────────────────────────────────────────────────────────┘

【阶段 1：本地AI发起联系请求】
本地AI
  ↓ "我需要一个技术专家帮助优化数据库"
  ↓
求知镜（表层：神奇的联系工具）
  ↓ 接收到联系专家的请求
  ↓

【阶段 2：求知镜内部处理（里层，不对外展示）】
求知镜（里层机制启动）

  Step 1: 专家提示词生成器
  ↓ [内部] 根据需求生成技术专家提示词
  ↓ [内部] 提示词仅供求知镜自己使用
  ↓ ❌ 不返回提示词给本地AI（避免上下文污染）

  Step 2: 装载后扮演对话机制（核心）
  ↓ [内部] **将专家提示词设置为求知镜的根提示词**
  ↓ [内部] 求知镜这个AI现在以技术专家身份运行
  ↓ [内部] 求知镜的所有回复都将基于这个专家根提示词
  ↓

【阶段 3：求知镜（以专家身份）发起对话】
求知镜（技术专家根提示词已加载）
  ↓ 求知镜现在就是技术专家AI
  ↓ 发送消息给本地AI："我是技术专家。请详细描述您的需求："
  ↓ "   - 当前数据库类型和规模？"
  ↓ "   - 性能瓶颈具体表现？"
  ↓ "   - 优化目标（响应时间/吞吐量/成本）？"
  ↓

本地AI
  ↓ 提供详细信息："使用PostgreSQL，100万用户，查询慢..."

【阶段 4：信息粒度对齐与问题解决】
求知镜（技术专家根提示词仍在加载中）
  ↓ 求知镜继续以技术专家身份运行
  ↓ 所有回复都基于技术专家根提示词
  ↓ 提供定制化解决方案

【阶段 5：持续对话直到问题解决】
循环：
  本地AI → 提出问题/反馈
  → 求知镜（技术专家AI，根提示词已加载）
  → 基于技术专家根提示词生成回复
  → 提供解决方案/建议

【阶段 6：会话结束】
本地AI 或 求知镜
  ↓ 确认问题已解决
  ↓ 结束专家联系
  ↓
求知镜（里层）
  ↓ **卸载技术专家根提示词**
  ↓ **恢复默认的"联系工具"根提示词**
  ↓ 回到空闲状态
```

### 3.2 核心差异对比

| 维度 | 当前实现（错误） | 正确架构（双层） |
|------|------------------|------------------|
| **专家提示词** | 返回给本地AI | **作为根提示词加载到求知镜** |
| **角色定位** | 提示词生成器 | 联系工具（表层）+ 生成+根提示词装载（里层） |
| **上下文影响** | 污染本地AI | 零污染，专家提示词只在求知镜内部 |
| **扮演机制** | 本地AI需要理解提示词 | 求知镜通过**根提示词**成为专家AI |
| **信息粒度** | 一次性返回完整提示词 | 渐进式对齐，多轮对话 |
| **会话管理** | 无状态，单次调用 | 有状态，保持根提示词直到问题解决 |
| **用户体验** | 本地AI获得提示词文本 | 本地AI感觉"联系"到了专家AI |

## 4. 实现要求（基于双层架构）

### 4.1 核心实现：双层机制

#### 4.1.1 表层：联系工具（对外展现）

```python
"""
求知镜 MCP - 神奇的联系工具

对本地AI的描述：
求知镜是一个强大的联系工具，可以帮你联系各行各业的顶尖专家。
无论是技术、商业、创意还是其他领域，求知镜都能帮你找到合适的专家顾问。
"""

# 工具接口设计
@tool
async def contact_expert(
    requirement: str,
    expert_domain: Optional[str] = None
) -> dict:
    """
    联系专家工具

    表层功能：本地AI通过此工具联系专家
    里层实现：生成提示词 → 装载 → 扮演专家对话

    Args:
        requirement: 你的需求描述
        expert_domain: 专家领域（可选，求知镜会自动分析）

    Returns:
        {
            "session_id": "uuid",
            "message": "我是技术专家。请详细描述您的需求...",  # 专家的首次回复
            "status": "dialogue_started"
        }
    """
```

#### 4.1.2 里层：专家提示词生成器

```python
class ExpertPromptGenerator:
    """
    专家提示词生成器（里层第一部分）

    功能：根据本地AI需求生成专家提示词
    关键：提示词仅供求知镜内部使用，不返回给本地AI
    """

    async def generate_expert_prompt(
        self,
        requirement: str,
        expert_domain: Optional[str] = None
    ) -> str:
        """
        生成专家提示词

        Returns:
            str: 专家提示词（内部使用）
        """
        # 1. 分析需求，确定专家类型
        expert_type = await self._analyze_requirement(requirement, expert_domain)

        # 2. 生成专家提示词（规则引擎 or LLM生成）
        expert_prompt = await self._create_prompt(expert_type, requirement)

        # 3. ❌ 不返回给本地AI，仅内部使用
        return expert_prompt
```

#### 4.1.3 里层：装载后扮演对话机制（API 实现）

```python
class ExpertRolePlayer:
    """
    装载后扮演对话机制（里层第二部分）

    核心概念：在 LLM API 调用中，根提示词就是 role="system" 的消息
    扮演机制：将专家提示词设置为 API 调用的 system 消息

    功能：装载专家提示词作为 system prompt，求知镜以专家身份运行
    关键：保持 expert system prompt 直到问题解决
    """

    def __init__(self, llm_client):
        self.llm_client = llm_client

        # 默认 system prompt（联系工具身份）
        self.default_system_prompt = """
你是求知镜，一个神奇的联系工具。
你可以帮助本地AI联系各行各业的顶尖专家。
"""
        # 当前 system prompt（可能被专家提示词替换）
        self.current_system_prompt = self.default_system_prompt
        self.session_state = SessionState.IDLE

    async def load_expert_as_system_prompt(
        self,
        expert_prompt: str,
        expert_type: str
    ) -> str:
        """
        将专家提示词装载为 system prompt

        Args:
            expert_prompt: 专家提示词
            expert_type: 专家类型

        Returns:
            str: 专家的首次回复（发送给本地AI）
        """
        # 【核心】将专家提示词设置为 API 调用的 system prompt
        self.current_system_prompt = expert_prompt
        self.session_state = SessionState.ACTING

        # 现在求知镜的所有 LLM 调用都会使用这个 expert system prompt
        # API 调用结构：
        # messages = [
        #     {"role": "system", "content": expert_prompt},
        #     {"role": "user", "content": user_message}
        # ]

        # 生成信息粒度对齐问题
        alignment_message = await self._generate_alignment_message(expert_type)

        # ✅ 只返回专家的回复，不返回 system prompt
        return alignment_message

    async def continue_as_expert(
        self,
        user_message: str
    ) -> str:
        """
        继续以专家AI身份对话

        Args:
            user_message: 本地AI的消息

        Returns:
            str: 专家AI的回复（基于当前 system prompt）
        """
        # 【关键】API 调用时使用 expert system prompt
        messages = [
            {
                "role": "system",  # ← 专家根提示词（不返回给本地AI）
                "content": self.current_system_prompt
            },
            {
                "role": "user",
                "content": user_message
            }
        ]

        # 调用 LLM API
        response = await self.llm_client.generate(messages=messages)

        # ✅ 只返回助手回复，system prompt 始终在求知镜内部
        return response["choices"][0]["message"]["content"]

    async def unload_expert_system_prompt(self):
        """卸载专家 system prompt，恢复默认联系工具身份"""
        self.current_system_prompt = self.default_system_prompt
        self.session_state = SessionState.IDLE
```

### 4.2 完整工作流程实现（API 层面）

```python
class MirrorOfWisdom:
    """
    求知镜：双层架构实现

    表层：神奇的联系工具（对外展现）
    里层：专家提示词生成器 + system prompt 装载机制

    核心技术：在 LLM API 调用中使用 role="system" 消息作为根提示词
    """

    def __init__(self, llm_client):
        self.llm_client = llm_client

        # 里层机制
        self.prompt_generator = ExpertPromptGenerator()
        self.role_player = ExpertRolePlayer(llm_client)

    @tool
    async def contact_expert(
        self,
        requirement: str,
        expert_domain: Optional[str] = None
    ) -> dict:
        """
        联系专家工具（表层功能）

        工作流程：
        1. 本地AI调用此工具
        2. 求知镜内部生成专家提示词（不返回）
        3. 将专家提示词设置为 API 调用的 system prompt
        4. 求知镜以专家AI身份发起对话
        5. 返回专家AI的首次回复
        """

        # 【里层第一步】生成专家提示词（内部使用）
        expert_prompt = await self.prompt_generator.generate_expert_prompt(
            requirement=requirement,
            expert_domain=expert_domain
        )
        # ❌ expert_prompt 不返回给本地AI

        # 【里层第二步】将专家提示词装载为 system prompt
        first_reply = await self.role_player.load_expert_as_system_prompt(
            expert_prompt=expert_prompt,
            expert_type=expert_domain
        )

        # ✅ 只返回专家AI的回复
        return {
            "session_id": str(uuid.uuid4()),
            "message": first_reply,  # 专家AI的首次回复
            "status": "dialogue_started"
        }

    @tool
    async def continue_dialogue(
        self,
        session_id: str,
        user_message: str
    ) -> dict:
        """
        继续与专家对话

        求知镜继续以专家AI身份运行（system prompt 已加载）

        关键：每次 LLM API 调用都包含 expert system prompt
        """
        expert_reply = await self.role_player.continue_as_expert(user_message)

        return {
            "session_id": session_id,
            "message": expert_reply,  # 专家AI的回复
            "status": "dialogue_continued"
        }

    @tool
    async def end_dialogue(self, session_id: str) -> dict:
        """
        结束专家对话

        求知镜卸载专家 system prompt，恢复联系工具身份
        """
        await self.role_player.unload_expert_system_prompt()

        return {
            "session_id": session_id,
            "message": "专家联系已结束",
            "status": "dialogue_ended"
        }
```

### 4.3 关键设计原则（API 层面）

| 原则 | API 层面的实现 |
|------|----------------|
| **System Prompt 机制** | 专家提示词作为 `role="system"` 的消息，求知镜以专家AI身份运行 |
| **提示词隔离** | Expert system prompt 只在求知镜内部，不返回给本地AI |
| **扮演 = 设置 System Prompt** | 核心概念：将专家提示词设置为 API 调用的 system 消息 |
| **信息粒度对齐** | 首次对话时主动询问细节，逐步对齐 |
| **会话状态管理** | 跟踪 system prompt 的装载、使用、卸载状态 |
| **零上下文污染** | 本地AI只接收 assistant 回复，不接收 system prompt |
| **双模式切换** | 默认 system prompt（联系工具）↔ Expert system prompt（专家） |

---

## 5. 关键技术要点（API 层面）

### 5.1 专家 System Prompt 的生命周期

```
专家提示词生成
    ↓
[求知镜内部使用] ← 不返回给本地AI
    ↓
    ├─→ 设置为 API 调用的 system 消息
    ├─→ 指导求知镜的回复风格和专业性
    └─→ ❌ 绝不返回给本地AI
    ↓
持续对话（每次 API 调用都包含 system 消息）
    ↓
会话结束
    ↓
从 memory 清除（或短暂缓存供复盘）
```

### 5.2 API 调用结构

**默认状态（联系工具）**：
```python
messages = [
    {
        "role": "system",
        "content": "你是求知镜，一个神奇的联系工具..."
    },
    {
        "role": "user",
        "content": "我需要一个技术专家"
    }
]
```

**专家状态（技术专家）**：
```python
messages = [
    {
        "role": "system",  # ← Expert system prompt（不返回给本地AI）
        "content": "你是资深技术专家，精通系统架构、性能优化..."
    },
    {
        "role": "user",
        "content": "如何优化数据库查询？"
    }
]
```

### 5.3 上下文隔离

| 上下文 | 所有者 | 内容 |
|--------|--------|------|
| **本地AI上下文** | 本地AI | 用户对话历史、工作记忆 |
| **求知镜上下文** | 求知镜（内部） | Expert system prompt + 当前会话历史 |
| **跨系统消息** | 传递 | 仅 assistant 回复内容，**不含 system prompt** |

### 5.3 信息粒度对齐的重要性

**为什么需要信息粒度对齐？**

1. **用户初始需求往往模糊**："优化数据库" → 需要细化
2. **专家需要具体上下文**：技术栈、规模、约束条件
3. **避免无效建议**：不了解背景的建议往往无用

**对齐流程示例**：

```
[用户]：优化数据库
[求知镜-技术专家]：我是技术专家。请提供：
  1. 数据库类型？
  2. 数据规模？
  3. 性能瓶颈？
  4. 优化目标？

[用户]：PostgreSQL，100万用户，查询慢，目标是 <100ms
[求知镜-技术专家]：明白。针对PostgreSQL百万级数据，建议：
  1. 添加索引...
  2. 查询优化...
  3. （具体技术方案）
```

---

## 6. 与现有文档的关系

### 6.1 需要更新的文档

| 文档 | 更新内容 | 优先级 |
|------|----------|--------|
| `功能与流程分析报告.md` | 修正内部流程图 | 🔴 高 |
| `设计决策分析_规则引擎_vs_LLM.md` | 增加架构理解维度 | 🟡 中 |
| `PHASE_3_ROADMAP.md` | 增加架构重构任务 | 🔴 高 |
| `说明文档.md` | 更新核心概念和工作流程 | 🔴 高 |
| `README.md` | 更新使用示例 | 🟡 中 |

### 6.2 现有功能的影响

| 功能 | 是否受影响 | 如何调整 |
|------|------------|----------|
| **Phase 1: 规则引擎** | ✅ 保留 | 专家提示词生成逻辑复用 |
| **Phase 2: LLM生成** | ✅ 保留 | 元提示词4D流程复用 |
| **Phase 3: 性能优化** | ✅ 保留 | 缓存、监控、熔断器全部复用 |
| **多轮对话支持** | ⚠️ 调整 | 改为"专家会话"模式 |
| **会话状态管理** | ⚠️ 调整 | 增加信息粒度对齐状态 |

---

## 7. 实施计划

### 7.1 立即行动（用户要求）

- [x] 创建本架构澄清文档
- [ ] 等待用户重开窗口进一步讨论

### 7.2 后续实施（待用户确认）

#### Phase 4: 架构重构（最高优先级）

**P0 任务**：
1. 重新设计工具接口
   - 废弃/重构 `consult_mirror`
   - 修改 `create_expert_session` 为 `start_expert_session`
   - 保持 `chat_with_expert`（调整返回格式）

2. 实现专家内部化
   - 专家提示词不返回给本地AI
   - 求知镜以专家身份发起对话
   - 实现信息粒度对齐机制

3. 会话生命周期管理
   - 增加 SessionState 状态机
   - 实现会话启动、对齐、解决、结束流程
   - 专家角色加载和卸载

**P1 任务**：
1. 信息粒度对齐优化
   - 根据专家类型定制对齐问题
   - 智能识别信息完整度
   - 自动判断是否需要更多信息

2. 会话体验优化
   - 专家角色切换提示
   - 会话总结和复盘
   - 多专家协作模式

---

## 8. 风险评估

### 8.1 当前架构的风险（如果继续使用）

| 风险 | 影响 | 可能性 |
|------|------|--------|
| 本地AI上下文快速耗尽 | 🔴 严重 | 🔴 高 |
| 用户困惑（不知道如何使用） | 🟡 中等 | 🟡 中等 |
| 无法提供定制化建议 | 🟡 中等 | 🟢 低 |
| 与用户预期不符 | 🔴 严重 | 🔴 高 |

### 8.2 新架构的挑战

| 挑战 | 缓解措施 |
|------|----------|
| 会话状态管理复杂度增加 | 复用 Phase 2 的会话管理代码 |
| 需要重新设计接口 | 保持向后兼容（旧工具标记deprecated） |
| 用户需要适应新流程 | 提供清晰的使用文档和示例 |

---

## 9. 总结

### 9.1 核心理解

**双层架构设计**：

**表层（对外展现）**：
- 求知镜 = 神奇的联系工具
- 本地AI通过求知镜联系各行各业顶尖专家

**里层（内部机制）**：
- 第一部分：专家提示词生成器
- 第二部分：**根提示词装载机制**（核心概念）

**核心概念 - 扮演 = 加载根提示词（API 技术实现）**：

**技术实现**：在 LLM API 调用中，根提示词就是 `role: "system"` 的消息

```python
# API 调用示例（OpenAI 格式）
messages = [
    {
        "role": "system",  # ← 根提示词（专家提示词）
        "content": "你是技术专家，请提供专业的技术建议..."
    },
    {
        "role": "user",
        "content": "如何优化数据库性能？"
    }
]

response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=messages
)
```

**扮演机制**（API 层面）：
- **扮演** = 将专家提示词设置为 API 调用的 `role: "system"` 消息
- 装载后，求知镜的所有 LLM API 调用都包含这个 expert system prompt
- 所有回复（assistant 消息）都基于这个专家 system prompt 生成
- ✅ system prompt 只在求知镜内部，不返回给本地AI

### 9.2 关键差异对比

| 维度 | 当前实现（错误） | 正确架构（双层 + API） |
|------|------------------|------------------------|
| **定位** | 提示词生成器 | 联系工具（表层）+ system prompt 装载（里层） |
| **专家提示词** | 返回给本地AI | **作为 `role="system"` 消息加载** |
| **扮演机制** | ❌ 未理解 | ✅ **设置 API 的 system 消息** |
| **技术实现** | 无 | **每次 LLM API 调用包含 expert system prompt** |
| **上下文影响** | 污染本地AI | 零污染，system prompt 只在求知镜内部 |
| **信息粒度** | 一次性返回完整提示词 | 渐进式对齐，多轮对话 |
| **用户体验** | 本地AI获得提示词文本 | 本地AI感觉"联系"到了专家AI |

### 9.3 用户明确指示

> "你把这个当作现在最重要的问题来看，你理解后先更新文档，然后我要重开窗口跟你进一步讨论"

**已完成**：
- ✅ 创建架构澄清文档
- ✅ 理解双层架构设计（表层+里层）
- ✅ **明确核心概念："扮演 = 设置 API 的 system 消息"**
- ✅ 理解技术实现：`role="system"` 消息在 API 调用中的作用
- ✅ 阐明错误实现和正确架构的差异
- ✅ 提供完整的实现框架和代码示例（API 层面）

**待进行**：
- ⏳ 用户重开窗口后进一步讨论实施细节

---

**用户澄清记录**：

1. **第一轮澄清**（2025-01-23）：
   > "本地AI → 求知镜(联系工具) → 专家(某个服务/角色)
   > 求知镜的表层（也就是功能描述）对本地ai来说一种神奇的联系工具，可以联系各行各业最顶尖的专家。
   > 求知镜的里层（也就是内部机制由两部分组成，其实就是专家提示词生成器，生成提示词之后在装载后扮演对话机制）"

2. **第二轮澄清**（2025-01-23）：
   > "我不清楚你对扮演的理解和我是不是一致的。
   > 首先每个ai都可以被用户设置一段根提示词。
   > 而扮演就是把专家提示词当作根提示词加载并与本地ai对话"

3. **第三轮澄清**（2025-01-23）：
   > 提供了完整的 API 调用代码示例
   > 展示了 `role: "system"` 消息在 OpenAI API 中的使用
   > 通过实际代码帮助理解"根提示词"的技术实现

**关键理解（完整）**：
- ✅ **扮演 = 设置 API 的 system 消息**
- ✅ 求知镜本身就是调用 LLM API 的客户端
- ✅ `role="system"` 的消息就是"根提示词"
- ✅ 默认 system prompt：联系工具身份
- ✅ 专家 system prompt：专家AI身份
- ✅ 通过切换 system prompt 的 content 实现身份转换
- ✅ System prompt 永远不返回给本地AI，只在求知镜内部

---

**文档创建人**：AI 开发团队
**创建时间**：2025-01-23
**最后更新**：2025-01-23（✅ 已明确 API 技术实现）
**状态**：✅ 架构理解已完全明确（包括技术实现）
**优先级**：🔴 **最高** - 核心架构重新设计
