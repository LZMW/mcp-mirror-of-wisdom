# DESIGN - Phase 4 架构重构设计

> 阶段2: Architect (架构阶段)
> 创建时间: 2025-01-23
> 基于: ALIGNMENT_Phase4.md
> 设计原则: 最小化变更，最大化复用

---

## 1. 整体架构设计

### 1.1 架构分层

```
┌─────────────────────────────────────────────────────────────┐
│                    MCP Server Layer                          │
│  (server.py - 工具注册与路由)                                 │
├─────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Tools Layer (工具层)                                 │   │
│  │                                                        │   │
│  │  1. start_expert_session (重命名自 consult_mirror)    │   │
│  │  2. create_expert_session (调整行为)                  │   │
│  │  3. chat_with_expert (保持不变)                        │   │
│  │  4. end_expert_session (重命名自 close_session)       │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Business Logic Layer (业务逻辑层)                     │   │
│  │                                                        │   │
│  │  SessionManager | PromptGenerator | LLMClient        │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Infrastructure Layer (基础设施层)                     │   │
│  │                                                        │   │
│  │  LLMMemoryCache | MetricsCollector | CircuitBreaker  │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 核心设计原则

**最小化变更原则**：
- ✅ 不创建新的 ExpertRolePlayer 类
- ✅ 复用 SessionManager 的 system_prompt 字段
- ✅ 复用 LLMClient 的 system prompt 机制
- ✅ 调整工具行为，而非架构

**代码复用策略**：
- SessionManager: 100% 复用（已有 system_prompt 管理）
- PromptGenerator: 100% 复用（已有元提示词生成）
- LLMClient: 100% 复用（已有 system prompt 注入）
- Phase 3 优化: 100% 复用（缓存、监控、熔断器）

---

## 2. 接口设计

### 2.1 start_expert_session 工具

**功能**：发起专家会话（重命名自 consult_mirror）

**输入模型**：
```python
class StartExpertSessionInput(BaseModel):
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra='forbid'
    )

    requirement: str = Field(
        ...,
        description="本地AI的原始需求描述",
        min_length=5,
        max_length=5000
    )

    expert_type: Optional[ExpertType] = Field(
        default=None,
        description="专家类型（可选，不指定则自动分析）"
    )

    context: Optional[str] = Field(
        default=None,
        description="可选的上下文信息"
    )

    requirements: Optional[str] = Field(
        default=None,
        description="可选的特殊要求"
    )
```

**返回格式**：
```python
{
    "session_id": "uuid-string",
    "expert_reply": "我是技术专家。请详细描述您的需求：\n1. 数据库类型？\n2. 数据规模？...",
    "expert_type": "technical",
    "status": "dialogue_started",
    "generation_method": "meta_prompt",
    "quality_score": 0.95
}
```

**工作流程**：
```
1. 验证输入参数
2. 生成专家提示词（内部，不返回）
   - 使用 PromptGenerator.generate_expert_prompt_with_meta()
   - 如果指定 expert_type，强制使用该类型
3. 创建会话（存储 system_prompt）
   - SessionManager.create_session(system_prompt=expert_prompt)
4. 生成专家首次回复
   - LLMClient.generate_chat(messages=[
       {"role": "system", "content": expert_prompt},
       {"role": "user", "content": "用户需求：{requirement}\n请主动询问细节以对齐信息粒度"}
     ])
5. 返回 session_id + expert_reply
   - ❌ 不返回 expert_prompt
   - ✅ 只返回专家首次回复
```

### 2.2 create_expert_session 工具

**功能**：创建专家会话（调整行为）

**输入模型**：保持不变（CreateSessionInput）

**返回格式**：
```python
{
    "session_id": "uuid-string",
    "expert_reply": "我是{专家类型}。{信息粒度对齐问题}",
    "generation_method": "meta_prompt",
    "quality_score": 0.95,
    "status": "dialogue_started"
}
```

**关键变更**：
- **之前**：返回会话创建确认
- **现在**：返回会话ID + 专家首次回复

**实现伪代码**：
```python
async def create_expert_session(params: CreateSessionInput) -> str:
    # 1. 生成专家提示词（内部）
    generation_result = await prompt_generator.generate_expert_prompt_with_meta(
        user_requirement=params.requirement
    )
    expert_prompt = generation_result["expert_prompt"]

    # 2. 创建会话
    session_id = await session_manager.create_session(
        system_prompt=expert_prompt,
        task_description=params.requirement
    )

    # 3. 生成专家首次回复（新增）
    messages = [
        {"role": "system", "content": expert_prompt},
        {"role": "user", "content": f"用户需求：{params.requirement}\n请主动询问细节以对齐信息粒度"}
    ]
    expert_reply = await llm_client.generate_chat(messages=messages)

    # 4. 更新会话历史（新增）
    await session_manager.update_session(
        session_id=session_id,
        user_message=params.requirement,
        assistant_response=expert_reply
    )

    # 5. 返回 session_id + expert_reply
    return f"""✅ **专家会话已创建**

**会话ID**: `{session_id}`

**任务描述**: {params.requirement[:100]}...

**生成方法**: {generation_result["generation_method"]}

**质量评分**: {generation_result["quality_score"]:.2f}

---

## 专家的首次回复

{expert_reply}

---

使用 `chat_with_expert` 工具继续对话。
"""
```

### 2.3 chat_with_expert 工具

**功能**：与专家对话（保持不变，已正确实现）

**输入模型**：保持不变（ChatInput）

**返回格式**：
```python
expert_response: str  # 专家的回复内容
```

**验证点**：
- ✅ 确认每次调用都使用 session.system_prompt
- ✅ System prompt 不返回给本地AI
- ✅ 对话历史正确管理

**现有实现**（expert_session.py:324-350）：
```python
# 对话上下文：system prompt + history + new message
messages = [
    {"role": "system", "content": session.system_prompt}  # ✅ 正确
]

# 添加历史对话
history_context = session.get_conversation_context(max_messages=50)
messages.extend(history_context)

# 添加新消息
messages.append({"role": "user", "content": params.message})

# 调用LLM
response = await llm_client.generate_chat(messages=messages)

# ✅ response 只包含 assistant 消息，不包含 system prompt
```

### 2.4 end_expert_session 工具

**功能**：结束专家会话（重命名自 close_session）

**输入模型**：保持不变（CloseSessionInput）

**返回格式**：
```python
{
    "session_id": "uuid-string",
    "message": "会话已结束",
    "summary": {
        "dialogue_rounds": 5,
        "duration_minutes": 15,
        "expert_type": "technical",
        "resolved": true,
        "created_at": "2025-01-23T10:00:00",
        "ended_at": "2025-01-23T10:15:00"
    },
    "status": "session_ended"
}
```

**可选增强**：
- 提供会话总结
- 提示专家角色已卸载
- 建议后续行动

---

## 3. 数据流设计

### 3.1 完整会话流程

```
┌─────────────────────────────────────────────────────────────┐
│ Step 1: 本地AI发起联系                                        │
└─────────────────────────────────────────────────────────────┘

本地AI
  ↓ start_expert_session(requirement="优化数据库")

求知镜内部处理：
  1. PromptGenerator.generate_expert_prompt_with_meta()
     ↓ 生成 expert_prompt（技术专家提示词）

  2. SessionManager.create_session(system_prompt=expert_prompt)
     ↓ 创建会话，存储 system_prompt（不返回给本地AI）

  3. LLMClient.generate_chat(messages=[
       {"role": "system", "content": expert_prompt},
       {"role": "user", "content": "用户需求：优化数据库。请主动询问细节。"}
     ])
     ↓ 生成 expert_reply："我是技术专家。请提供：1. 数据库类型？2. 规模？"

返回本地AI：
  {
    "session_id": "abc-123",
    "expert_reply": "我是技术专家。请提供：1. 数据库类型？2. 规模？...",
    "status": "dialogue_started"
  }

本地AI上下文：
  ✅ session_id: "abc-123"
  ✅ expert_reply: "我是技术专家..."
  ❌ 没有 expert_prompt（零污染）


┌─────────────────────────────────────────────────────────────┐
│ Step 2: 本地AI提供详细信息                                    │
└─────────────────────────────────────────────────────────────┘

本地AI
  ↓ chat_with_expert(session_id="abc-123", message="PostgreSQL，100万用户")

求知镜内部处理：
  1. SessionManager.get_session("abc-123")
     ↓ 获取会话，包含 system_prompt

  2. 构建消息：
     messages = [
       {"role": "system", "content": session.system_prompt},
       {"role": "user", "content": "PostgreSQL，100万用户"}
     ]

  3. LLMClient.generate_chat(messages=messages)
     ↓ 生成 expert_reply："针对PostgreSQL百万级数据，建议：1. 添加索引..."

返回本地AI：
  "针对PostgreSQL百万级数据，建议：1. 添加索引 2. 优化查询..."

本地AI上下文：
  ✅ 只接收专家回复（持续零污染）


┌─────────────────────────────────────────────────────────────┐
│ Step 3: 问题解决，结束会话                                    │
└─────────────────────────────────────────────────────────────┘

本地AI
  ↓ end_expert_session(session_id="abc-123")

求知镜内部处理：
  1. SessionManager.close_session("abc-123")
     ↓ 标记会话为 COMPLETED
     ↓ 清理会话数据

返回本地AI：
  {
    "session_id": "abc-123",
    "message": "会话已结束",
    "summary": {...},
    "status": "session_ended"
  }

求知镜内部：
  ✅ expert system_prompt 已卸载
  ✅ 恢复默认联系工具身份
```

### 3.2 关键数据结构

**Session 数据结构**（已有）：
```python
@dataclass
class Session:
    session_id: str
    system_prompt: str  # ← Expert system prompt（不返回给本地AI）
    task_description: str
    state: SessionState
    history: List[Message]
    created_at: datetime
    last_activity: datetime
    quality_score: float
    message_count: int
```

**Message 数据结构**（已有）：
```python
@dataclass
class Message:
    role: Literal["user", "assistant"]
    content: str
    timestamp: datetime
```

---

## 4. 状态机设计

### 4.1 会话状态机

```
┌─────────────────────────────────────────────────────────────┐
│                    会话状态机                                │
└─────────────────────────────────────────────────────────────┘

IDLE（空闲状态）
  ↓ start/create_expert_session
  ↓
CREATED（已创建）
  - expert system_prompt 已加载
  - 等待首次对话
  ↓
  ├─→ chat_with_expert（首次）
  │   ↓
  │   ACTIVE（活跃对话）
  │   - 持续对话中
  │   - 每次对话更新 last_activity
  │   ↓
  │   ├─→ chat_with_expert（继续）
  │   │   ↓
  │   │   ACTIVE（保持活跃）
  │   │
  │   └─→ end_expert_session / TTL过期
  │       ↓
  │       COMPLETED（已完成）
  │
  └─→ 直接 end_expert_session
      ↓
      COMPLETED

COMPLETED → 清理（从内存删除）
```

### 4.2 System Prompt 生命周期

```
┌─────────────────────────────────────────────────────────────┐
│              System Prompt 生命周期                          │
└─────────────────────────────────────────────────────────────┘

默认状态（会话前/会话后）：
  system_prompt = "你是求知镜，一个神奇的联系工具..."

会话创建后（CREATED/ACTIVE）：
  system_prompt = "你是资深技术专家，精通系统架构、数据库优化..."
  - 指导求知镜的所有回复
  - 保持专家角色一致性
  - ❌ 不返回给本地AI

会话结束后（COMPLETED）：
  system_prompt = "你是求知镜，一个神奇的联系工具..."
  - 卸载专家角色
  - 恢复默认身份
```

### 4.3 状态转换规则

| 当前状态 | 触发事件 | 目标状态 | 动作 |
|---------|---------|---------|------|
| IDLE | start/create_expert_session | CREATED | 加载expert system_prompt |
| CREATED | chat_with_expert | ACTIVE | 首次对话，更新历史 |
| ACTIVE | chat_with_expert | ACTIVE | 继续对话，更新last_activity |
| ACTIVE/CREATED | end_expert_session | COMPLETED | 卸载expert system_prompt |
| 任何状态 | TTL过期（30分钟） | 清理 | 删除会话数据 |

---

## 5. 错误处理策略

### 5.1 错误分类

| 错误类型 | 严重性 | 处理策略 | 用户提示 |
|---------|--------|---------|---------|
| 输入验证错误 | 🟡 中等 | 立即返回错误 | "需求描述不能为空" |
| 会话不存在/过期 | 🟡 中等 | 提示重新创建 | "会话已过期，请重新创建" |
| LLM调用失败 | 🔴 严重 | 降级/重试 | "暂时无法连接，请稍后重试" |
| 元提示词失败 | 🟡 中等 | 回退规则引擎 | 自动降级，用户无感知 |
| 并发冲突 | 🟢 低 | 自动排队处理 | 无需用户关心 |
| 资源耗尽 | 🔴 严重 | 清理+告警 | "服务繁忙，请稍后重试" |

### 5.2 降级策略

**元提示词生成失败**：
```
LLM生成 → 失败
  ↓
规则引擎 → 成功（使用）
  ↓
规则引擎 → 失败
  ↓
返回错误（不创建会话）
```

**LLM对话调用失败**：
```
LLM调用 → 超时/网络错误
  ↓
熔断器检查 → 如果开启，直接返回错误
  ↓
如果熔断器关闭 → 重试1次（配置）
  ↓
仍然失败 → 返回友好错误，保留会话状态
```

### 5.3 错误响应格式

```python
{
    "error": true,
    "error_type": "session_not_found",
    "error_message": "用户可读的错误描述",
    "suggestion": "解决建议",
    "technical_details": "技术细节（可选）"
}
```

### 5.4 日志规范

| 级别 | 场景 | 示例 |
|------|------|------|
| ERROR | 所有错误 | `logger.error(f"LLM调用失败: {e}")` |
| WARNING | 降级触发 | `logger.warning("元提示词生成失败，回退到规则引擎")` |
| INFO | 正常操作 | `logger.info(f"会话创建成功: {session_id}")` |
| DEBUG | 详细调试 | `logger.debug(f"构建消息: {messages}")` |

---

## 6. 性能考虑

### 6.1 性能目标

| 指标 | 目标 | 说明 |
|------|------|------|
| 工具调用响应时间 | < 100ms | 不含LLM调用时间 |
| LLM调用响应时间 | < 30s | 包含网络和生成时间 |
| 缓存命中率 | > 70% | 相似需求的专家提示词复用 |
| 会话并发数 | > 100 | 同时活跃的会话数 |

### 6.2 性能优化策略

**复用 Phase 3 优化**：
- ✅ LLMMemoryCache：缓存专家提示词
- ✅ MetricsCollector：监控性能指标
- ✅ CircuitBreaker：防止级联失败
- ✅ 异步非阻塞：使用 asyncio

**新增优化**：
- 会话历史滑动窗口（最多100条消息）
- TTL自动清理（30分钟无活动）
- 批量操作（一次性更新历史）

---

## 7. 安全考虑

### 7.1 数据安全

- ✅ System prompt 永远不返回给本地AI
- ✅ 会话数据仅在内存存储（可选持久化）
- ✅ TTL自动清理，防止内存泄漏

### 7.2 API安全

- ✅ 输入验证：Pydantic v2严格验证
- ✅ 长度限制：防止超长输入
- ✅ 类型检查：防止注入攻击

### 7.3 并发安全

- ✅ SessionManager._lock：保证原子性
- ✅ 状态机：明确定义的状态转换
- ✅ 协程安全：使用 asyncio.Lock

---

## 8. 测试策略

### 8.1 单元测试

**需要测试的模块**：
1. `start_expert_session` 工具
   - 输入验证
   - 专家提示词生成
   - 会话创建
   - 首次回复生成

2. `create_expert_session` 工具（调整后）
   - 验证返回 expert_reply
   - 验证会话历史更新

3. `chat_with_expert` 工具（验证）
   - System prompt 注入
   - 对话历史管理

4. `end_expert_session` 工具
   - 会话关闭
   - 角色卸载

### 8.2 集成测试

**测试场景**：
1. 完整会话流程
   - start → chat → end
   - 验证 system prompt 不泄露

2. 错误场景
   - 会话不存在
   - LLM调用失败
   - TTL过期

3. 并发场景
   - 多个会话同时进行
   - 同一会话并发操作

### 8.3 端到端测试

**测试流程**：
```
1. 本地AI调用 start_expert_session
   ↓ 验证：返回 session_id + expert_reply

2. 本地AI调用 chat_with_expert
   ↓ 验证：返回专家回复（零污染）

3. 本地AI调用 end_expert_session
   ↓ 验证：会话关闭，返回总结
```

---

## 9. 实施计划

### 9.1 P0 任务（核心）

**Task 1: 修改 create_expert_session**
- 文件：`src/tools/expert_session.py`
- 变更：添加首次回复生成逻辑
- 预估时间：2小时

**Task 2: 验证 chat_with_expert**
- 文件：`src/tools/expert_session.py`
- 变更：确认 system prompt 机制
- 预估时间：1小时

### 9.2 P1 任务（重要）

**Task 3: 重命名 consult_mirror → start_expert_session**
- 文件：`src/tools/consult_mirror.py`
- 变更：重命名 + 调整返回格式
- 预估时间：1.5小时

**Task 4: 更新 server.py**
- 文件：`src/server.py`
- 变更：更新工具注册
- 预估时间：0.5小时

### 9.3 P2 任务（优化）

**Task 5: 增强 end_expert_session**
- 文件：`src/tools/expert_session.py`
- 变更：添加会话总结
- 预估时间：1小时

**Task 6: 编写迁移指南**
- 文件：`docs/求知镜MCP/MIGRATION_Phase4.md`
- 变更：新建文档
- 预估时间：1小时

### 9.4 P3 任务（文档）

**Task 7: 更新所有文档**
- 变更：更新说明文档、README等
- 预估时间：2小时

**Task 8: 编写测试**
- 文件：`tests/test_phase4.py`
- 变更：新建测试文件
- 预估时间：3小时

**总预估时间**：12小时

---

## 10. 验收标准

### 10.1 功能验收

- ✅ `start_expert_session` 返回专家首次回复
- ✅ `create_expert_session` 返回专家首次回复
- ✅ `chat_with_expert` 正确使用 system prompt
- ✅ `end_expert_session` 正确卸载专家角色
- ✅ System prompt 未返回给本地AI
- ✅ 多轮对话保持专家角色一致性

### 10.2 性能验收

- ✅ 工具调用响应时间 < 100ms
- ✅ Phase 3 性能优化仍然有效
- ✅ 缓存命中率 > 70%

### 10.3 质量验收

- ✅ 代码风格符合项目规范
- ✅ 函数注释完整
- ✅ 单元测试覆盖率 > 80%
- ✅ 集成测试全部通过

---

## 11. 相关文档

### 11.1 上游文档

1. **ALIGNMENT_Phase4.md**
   - 需求分析和边界定义
   - 核心目标和验收标准

2. **ARCHITECTURE_CLARIFICATION.md**
   - 双层架构详细说明
   - API技术实现参考

3. **ACCEPTANCE_Phase3.md**
   - 当前功能基线
   - 性能优化清单

### 11.2 下游文档

1. **TASK_Phase4.md**（待创建）
   - 详细任务拆分
   - 依赖关系图

2. **MIGRATION_Phase4.md**（待创建）
   - 新旧接口对比
   - 使用示例

3. **ACCEPTANCE_Phase4.md**（待创建）
   - 验收报告
   - 测试结果

---

## 12. 附录

### 12.1 术语表

| 术语 | 定义 |
|------|------|
| System Prompt | LLM API 中 role="system" 的消息，作为根提示词指导AI行为 |
| 专家内部化 | 专家提示词仅在求知镜内部使用，不返回给本地AI |
| 信息粒度对齐 | 专家主动询问细节，确保理解用户需求 |
| 会话生命周期 | 从创建到结束的完整状态转换过程 |
| 零上下文污染 | 本地AI上下文窗口不包含专家提示词 |

### 12.2 代码片段

**System Prompt 注入示例**：
```python
# LLM API 调用结构
messages = [
    {
        "role": "system",  # ← Expert system prompt（不返回给本地AI）
        "content": session.system_prompt
    },
    {
        "role": "user",
        "content": user_message
    }
]

response = await llm_client.generate_chat(messages=messages)

# ✅ response 只包含 assistant 消息
# ❌ system prompt 永远不会返回给本地AI
```

### 12.3 决策记录

| 决策点 | 选择 | 理由 |
|--------|------|------|
| 是否创建 ExpertRolePlayer 类 | 否 | 复用 SessionManager，最小化变更 |
| 如何处理 consult_mirror | 重命名为 start_expert_session | 更清晰的语义 |
| 如何生成首次回复 | 在工具内调用 LLM | 简化流程，减少工具调用次数 |
| 是否向后兼容 | 标记旧接口为 deprecated | 平滑过渡 |

---

**文档创建人**：AI 开发团队
**创建时间**：2025-01-23
**状态**：✅ Architect 阶段完成
**下一步**：Atomize 阶段 - 任务拆分
