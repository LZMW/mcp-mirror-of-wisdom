# DESIGN - 求知镜 MCP 架构设计

> 阶段2: Architect (架构阶段)
> 创建时间: 2025-01-21
> 基于: ALIGNMENT_项目初始化.md

---

## 1. 系统架构

### 整体架构图

```mermaid
graph TB
    Client[Claude/Desktop Client] -->|MCP Protocol| Server[MCP Server]
    Server -->|Call| Tool[consult_mirror Tool]
    Tool -->|Validate| Input[Input Validation]
    Input -->|Select Expert| Library[Expert Library]
    Library -->|Generate| Formatter[Prompt Formatter]
    Formatter -->|Return| Tool
    Tool -->|Response| Server
    Server -->|stdio| Client

    subgraph "Expert Library"
        E1[Technical]
        E2[Creative]
        E3[Business]
        E4[Education]
        E5[Writing]
        E6[Research]
        E7[Philosophy]
        E8[General]
    end
```

### 分层设计

```
┌─────────────────────────────────────────┐
│  Presentation Layer (表现层)            │
│  - MCP Server (server.py)               │
│  - FastMCP 框架                          │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Tool Layer (工具层)                     │
│  - consult_mirror (consult_mirror.py)    │
│  - Input Validation (Pydantic)           │
│  - Output Formatting                     │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Business Logic Layer (业务逻辑层)      │
│  - Expert Library (prompt_generator.py)  │
│  - 8 Expert Types                        │
│  - Prompt Generation Logic               │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Config Layer (配置层)                   │
│  - Environment Variables (.env)          │
│  - Config Management (config.py)         │
└─────────────────────────────────────────┘
```

---

## 2. 核心组件设计

### 2.1 MCP Server (server.py)

**职责**：
- 初始化 FastMCP 服务器
- 注册 consult_mirror 工具
- 配置日志和错误处理

**接口**：
```python
def main():
    """启动 MCP 服务器"""
    mcp = FastMCP("mirror_of_wisdom_mcp")
    mcp.run()  # stdio 传输
```

**配置**：
- 传输协议：stdio
- 日志级别：INFO/DEBUG/WARNING/ERROR
- 端口：不适用（stdio）

---

### 2.2 consult_mirror Tool (consult_mirror.py v2)

**职责**：
- MCP 工具实现
- 输入参数验证
- 专家提示词生成
- 输出格式化

**输入模型**：
```python
class ConsultMirrorInput(BaseModel):
    expert_type: ExpertType        # 必需
    task_description: str           # 必需，5-2000字符
    context: Optional[str]          # 可选
    requirements: Optional[str]     # 可选
    response_format: ResponseFormat # markdown/json
```

**输出格式**：

**Markdown**：
```markdown
# 专家名称

## 任务描述
用户任务描述

## 背景上下文 (可选)
上下文信息

## 特殊要求 (可选)
特殊要求

## 专家角色设定
系统提示词内容

---

现在请以专家名称的身份，针对上述任务提供专业指导。
```

**JSON**：
```json
{
  "expert_type": "technical",
  "expert_name": "技术专家",
  "system_prompt": "...",
  "task_description": "...",
  "context": "...",
  "requirements": "...",
  "generation_method": "direct",
  "quality_score": 1.0,
  "quality_check_passed": true
}
```

---

### 2.3 Expert Library (prompt_generator.py)

**EXPERT_LIBRARY 结构**：
```python
EXPERT_LIBRARY = {
    "technical": {
        "name": "技术专家",
        "keywords": ["代码", "编程", "开发", ...],
        "system_prompt": """你是一位资深的软件技术专家..."""
    },
    "creative": {
        "name": "创意设计师",
        "keywords": ["设计", "创意", "UI", ...],
        "system_prompt": """你是一位富有创造力的设计专家..."""
    },
    ... # 8 种专家
}
```

**方法**：
```python
def format_expert_prompt(
    expert_type: str,
    task_description: str,
    context: Optional[str] = None,
    requirements: Optional[str] = None
) -> str:
    """格式化专家提示词为可读文本"""
```

---

### 2.4 Config Management (config.py)

**配置类**：

**MirrorConfig**（备用，未在 v2 中使用）：
```python
class MirrorConfig(BaseModel):
    provider: Literal["openai", "anthropic", ...]
    api_key: str
    model: str
    temperature: float
    max_tokens: int
```

**ServerConfig**：
```python
class ServerConfig(BaseModel):
    name: str = "Mirror of Wisdom MCP"
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"]
    enable_quality_check: bool = True
    quality_threshold: float = 0.8
```

---

## 3. 数据流设计

### 3.1 正常流程

```mermaid
sequenceDiagram
    participant C as Client
    participant S as Server
    participant T as Tool
    participant E as Expert Library

    C->>S: MCP Call
    S->>T: consult_mirror(params)
    T->>T: Validate Input
    T->>E: Get Expert Info
    E-->>T: Expert Data
    T->>T: Format Prompt
    T-->>S: Result
    S-->>C: Response
```

### 3.2 错误处理流程

```mermaid
sequenceDiagram
    participant C as Client
    participant S as Server
    participant T as Tool

    C->>S: MCP Call (Invalid Input)
    S->>T: consult_mirror(params)
    T->>T: Validate Input (Fail)
    T-->>S: Error Message
    S-->>C: Error Response
```

---

## 4. 接口规范

### 4.1 MCP Tool 接口

**工具名称**: `consult_mirror`

**参数**：
| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| expert_type | enum | ✅ | 专家类型 |
| task_description | string | ✅ | 任务描述 |
| context | string | ❌ | 上下文信息 |
| requirements | string | ❌ | 特殊要求 |
| response_format | enum | ❌ | 输出格式（默认 markdown） |

**返回值**：
- 成功：格式化的专家提示词（string）
- 失败：错误信息（string）

### 4.2 专家类型枚举

```python
class ExpertType(str, Enum):
    TECHNICAL = "technical"      # 技术专家
    CREATIVE = "creative"        # 创意设计师
    BUSINESS = "business"        # 商业战略顾问
    EDUCATION = "education"      # 教育专家
    WRITING = "writing"          # 写作顾问
    RESEARCH = "research"        # 研究分析师
    PHILOSOPHY = "philosophy"    # 哲学思考者
    GENERAL = "general"          # 通用助手
```

---

## 5. 异常处理策略

### 5.1 输入验证错误

**场景**：
- expert_type 无效
- task_description 太短（< 5字符）
- task_description 太长（> 2000字符）

**处理**：
```python
except ValueError as e:
    return f"**错误**: {str(e)}\n\n请检查你的输入并重试。"
```

### 5.2 系统异常

**场景**：
- 专家库访问失败
- 格式化失败

**处理**：
```python
except Exception as e:
    logger.error(f"consult_mirror 执行失败: {e}", exc_info=True)
    return """
    **求知镜暂时无法处理你的请求**

    错误信息: {str(e)}

    建议：
    1. 检查专家类型是否正确
    2. 检查任务描述是否清晰
    ...
    """
```

---

## 6. 性能考虑

### 6.1 响应时间

**目标**：< 10ms

**优化措施**：
1. 专家库预加载（内存）
2. 无网络调用（v2 设计）
3. 简单字符串拼接

### 6.2 内存占用

**目标**：< 50MB

**优化措施**：
1. 专家库静态定义
2. 无缓存需求
3. 无数据库连接

---

## 7. 扩展性设计

### 7.1 新增专家类型

**步骤**：
1. 在 `EXPERT_LIBRARY` 添加新专家
2. 在 `ExpertType` 枚举添加新类型
3. 更新文档

**示例**：
```python
EXPERT_LIBRARY["legal"] = {
    "name": "法律顾问",
    "keywords": ["法律", "合同", "法规", ...],
    "system_prompt": """你是一位专业的法律顾问..."""
}
```

### 7.2 Phase 2 扩展点

1. **会话管理**：添加 session_manager 模块
2. **多轮对话**：扩展 stage 参数支持 "in_dialogue"
3. **角色切换**：新增 change_reflection 工具

---

## 8. 安全考虑

### 8.1 输入安全

1. **长度限制**：防止超长输入导致内存溢出
2. **内容过滤**：可选的敏感词过滤（Phase 2）
3. **类型验证**：Pydantic 严格类型检查

### 8.2 输出安全

1. **格式验证**：确保输出格式正确
2. **错误隐藏**：不暴露内部实现细节
3. **日志脱敏**：敏感信息不记录日志

---

## 9. 测试策略

### 9.1 单元测试

- `test_config.py`：配置管理测试
- `test_prompt_generator.py`：提示词生成器测试
- `test_consult_mirror.py`：工具集成测试

### 9.2 集成测试

- `test_server.py`：服务器集成测试
- MCP Inspector 手动测试

### 9.3 覆盖率目标

- 核心模块：> 80%
- 工具层：100%
- 专家库：100%

---

## 10. 部署架构

### 10.1 本地部署

```bash
# 安装
pip install -e .

# 配置
cp .env.example .env

# 运行
python -m mirror_of_wisdom.server
```

### 10.2 Claude Desktop 集成

**配置文件**：`claude_desktop_config.json`

```json
{
  "mcpServers": {
    "mirror-of-wisdom": {
      "command": "python",
      "args": ["-m", "mirror_of_wisdom.server"]
    }
  }
}
```

---

**设计完成时间**: 2025-01-21
**设计版本**: v2.0 (简化设计)
**下一步**: 进入 Atomize 阶段，拆分任务
