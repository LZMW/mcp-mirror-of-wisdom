# Phase 3 路线图

> 规划时间: 2025-01-22
> 基于: Phase 2 v0.3.0 验收完成
> 状态: **已完成**（P0/P1/P2 全部完成）
> 更新时间: 2025-01-23

---

## 1. Phase 2 回顾

### 1.1 已完成功能

**核心功能**：
- ✅ 规则引擎模式（Phase 1）
- ✅ LLM 生成模式（Phase 2）
- ✅ 混合运行模式（use_llm 参数）
- ✅ 智能任务分析与置信度评分
- ✅ 自动回退机制

**质量指标**：
- ✅ 测试通过率：100% (39/39)
- ✅ LLM 模式成功率：100%
- ✅ JSON 解析错误：0
- ✅ 平均置信度：0.985
- ⚠️ 平均响应时间：13.28秒（Phase 3 已优化）

### 1.2 遗留问题（Phase 3 已解决）

**性能问题**（已解决）：
- ✅ LLM 调用响应时间长（平均 13.28秒）→ 通过缓存规避
- ✅ 网络波动导致超时 → 超时延长至 90s
- ✅ 无缓存机制 → 已实现持久化缓存

**并发问题**（已解决）：
- ✅ 异步阻塞问题 → 修复 time.sleep → asyncio.sleep
- ✅ 重试策略粗糙 → 精细化重试（禁止 Timeout 重试）

---

## 2. Phase 3 目标（已调整）

### 2.1 核心目标

**主要目标**：性能优化与生产准备

**关键认知调整**（基于上级顾问指导）：
> **核心洞察**：LLM 响应慢（13.28秒）主要是 API 服务器端的推理生成慢，这是**外部不可控因素**。
> **优化策略**：既然无法"加速"推理，优化的唯一出路是**"规避"推理**。

**修正后的具体目标**：
1. **缓存优先**：通过持久化缓存规避重复 LLM 调用
2. **异步非阻塞**：修复事件循环阻塞，确保长耗时推理期间服务可用
3. **超时延长**：延长超时至 90s（覆盖 72s 异常值）
4. **精细化重试**：禁止对 Timeout 重试，避免服务端积压

### 2.2 KPI 目标修正

| 指标 | 原目标 | 修正后目标 | 说明 |
|------|--------|-----------|------|
| **全局响应时间** | P95 < 5s | 冷启动允许 < 90s | 承认 API 生成慢的物理限制 |
| **缓存命中响应** | - | **< 50ms** | 规避推理，直接返回缓存 |
| **并发处理** | - | **无阻塞** | LLM 请求期间缓存请求不受影响 |
| **持久化** | - | **重启后有效** | 避免重复 13s 预热 |

---

## 3. 已完成工作（P0 + P1）

### 3.1 P0 任务 ✅

#### 3.1.1 修复异步阻塞问题

**问题**：
- `llm_client.py:166` 中，`async` 函数内使用了 `time.sleep()`
- 会阻塞整个事件循环，导致长耗时推理期间服务假死

**解决方案**：
```python
# 修复前（错误）
time.sleep(self.config.retry_delay)

# 修复后（正确）
import asyncio
await asyncio.sleep(self.config.retry_delay)
```

**验收结果**：
- ✅ 并发测试通过：缓存请求在 LLM 请求期间响应时间 9.85ms（< 50ms）

#### 3.1.2 实现持久化缓存机制

**功能**：
1. **内存 LRU 缓存**：快速访问
2. **SQLite 持久化**：服务重启后仍有效
3. **TTL 过期**：默认 1 小时
4. **基于哈希的 Key**：`MD5(prompt + system_prompt + format)`

**实现**：
- 新增文件：`src/mirror_of_wisdom/llm_cache.py`
- 集成到：`llm_client.generate()` 方法
- 缓存目录：`.cache/llm_cache.db`

**验收结果**：
- ✅ 持久化测试通过：服务重启后缓存仍然有效
- ✅ 统计功能：`cache.get_stats()` 返回缓存命中率、数据库大小等

**代码示例**：
```python
from mirror_of_wisdom.llm_cache import get_llm_cache

cache = get_llm_cache()

# 保存到缓存
cache.set(prompt, response, system_prompt, ttl=3600)

# 从缓存读取
cached = cache.get(prompt, system_prompt)

# 获取统计信息
stats = cache.get_stats()
print(f"缓存命中数: {stats['total_hits']}")
print(f"数据库大小: {stats['db_size_mb']} MB")
```

### 3.2 P1 任务 ✅

#### 3.2.1 调整超时配置

**变更**：
- 默认超时：30s → **90s**
- 覆盖异常值：72s（网络波动）

**实现**：
- 修改文件：`src/mirror_of_wisdom/config.py`
- 更新文件：`.env.example`

#### 3.2.2 精细化重试策略

**问题**：
- 原重试策略对 Timeout 也重试，会导致服务端积压

**解决方案**：
```python
# 禁止对 Timeout 重试（避免服务端积压）
is_timeout = (
    "timeout" in error_type.lower() or
    "timed out" in str(e).lower() or
    (HTTPX_AVAILABLE and isinstance(e, TimeoutException))
)

if is_timeout:
    # 超时错误不重试，直接抛出
    logger.warning("⏱️ 请求超时（不重试，避免服务端积压）")
    raise

# 仅对 ConnectionError 和 HTTP 5xx 重试
is_retryable = (
    (HTTPX_AVAILABLE and isinstance(e, ConnectError)) or
    "ConnectionError" in error_type or
    "connect" in str(e).lower() or
    "5" in str(e)  # HTTP 5xx 错误
)
```

**验收结果**：
- ✅ 模拟测试通过：超时错误被正确识别（不重试）

---

## 4. 已完成工作（P2）✅

### 4.2 性能监控与告警 ✅

**已实现功能**：
1. **性能指标收集**：
   - ✅ LLM 响应时间（P50, P95, P99）
   - ✅ 缓存命中率
   - ✅ 规则引擎响应时间
   - ✅ 专家类型使用统计

2. **可靠性指标**：
   - ✅ LLM 调用成功率
   - ✅ 降级率
   - ✅ 错误分类统计

3. **导出功能**：
   - ✅ JSON 格式导出
   - ✅ 格式化报告打印
   - ✅ 实时统计查看

**实现**：
- 新增文件：`src/mirror_of_wisdom/metrics.py`
- 集成到：`llm_client.generate()` 方法
- 核心类：`MetricsCollector`

**代码示例**：
```python
from mirror_of_wisdom.metrics import get_metrics

metrics = get_metrics()

# 记录 LLM 调用
metrics.record_llm_call(
    success=True,
    response_time=1.5,
    expert_type="technical"
)

# 生成报告
report = metrics.get_report()
print(f"成功率: {report['llm_metrics']['success_rate']}%")

# 导出 JSON
metrics.export_to_json("metrics_report.json")

# 打印报告
metrics.print_report()
```

**验收结果**：
- ✅ 测试通过：3/3 测试全部通过
- ✅ 指标收集准确：LLM 调用、缓存、响应时间
- ✅ 报告生成正常：JSON 导出、格式化打印

### 4.3 熔断器模式 ✅

**已实现功能**：
- ✅ 连续失败阈值（默认 5 次）
- ✅ 熔断超时（默认 60 秒）
- ✅ 半开状态探测
- ✅ 自动恢复机制
- ✅ 状态查询接口

**实现**：
- 新增文件：`src/mirror_of_wisdom/circuit_breaker.py`
- 集成到：`llm_client.generate()` 方法
- 核心类：`CircuitBreaker`
- 状态机：CLOSED → OPEN → HALF_OPEN → CLOSED

**代码示例**：
```python
from mirror_of_wisdom.circuit_breaker import get_circuit_breaker

circuit_breaker = get_circuit_breaker(
    failure_threshold=5,
    timeout=60.0,
    success_threshold=2
)

# 查询状态
state_info = circuit_breaker.get_state_info()
print(f"当前状态: {state_info['state']}")

# 重置熔断器
circuit_breaker.reset()
```

**验收结果**：
- ✅ 测试通过：熔断器状态转换正确
- ✅ 失败阈值触发：5 次失败后开启
- ✅ 超时恢复：60 秒后进入半开状态
- ✅ 探测成功：2 次成功后恢复到关闭状态

---

## 5. 验收标准（最终）

### 5.1 全部验收通过 ✅

| 指标 | 目标 | 实际结果 | 状态 |
|------|------|----------|------|
| 异步非阻塞 | 缓存请求不被阻塞 | 9.85ms（< 50ms） | ✅ 通过 |
| 持久化缓存 | 重启后仍有效 | 缓存正常恢复 | ✅ 通过 |
| 超时配置 | ≥ 90s | 90s（环境变量可覆盖） | ✅ 通过 |
| 精细化重试 | Timeout 不重试 | 逻辑正确 | ✅ 通过 |
| 性能监控 | 收集所有关键指标 | LLM/缓存/响应时间/错误 | ✅ 通过 |
| 熔断器 | 连续失败后熔断 | 5 次失败后开启 | ✅ 通过 |

---

## 6. 测试报告

### 6.1 P0/P1 测试套件

**测试文件**：`.ai_temp/test_phase3_fixes.py`

**测试用例**：
1. ✅ 并发非阻塞验证
2. ✅ 持久化验证
3. ✅ 超时配置验证
4. ✅ 精细化重试策略（模拟）

**测试结果**：
```
============================================================
测试结果汇总
============================================================
test_concurrent: ✅ 通过
test_persistence: ✅ 通过
test_timeout: ✅ 通过
test_retry: ✅ 通过

总计: 4/4 测试通过

🎉 所有测试通过！Phase 3 P0/P1 优化验证成功
```

### 6.2 P2 测试套件

**测试文件**：`.ai_temp/test_phase3_p2.py`

**测试用例**：
1. ✅ 性能监控指标收集
2. ✅ 熔断器状态转换
3. ✅ 集成测试（监控 + 熔断器）

**测试结果**：
```
============================================================
测试结果汇总
============================================================
test_metrics: ✅ 通过
test_circuit_breaker: ✅ 通过
test_integration: ✅ 通过

总计: 3/3 测试通过

🎉 所有测试通过！Phase 3 P2 功能验证成功
```

---

## 7. 文件变更记录（最终）

### 7.1 新增文件

| 文件 | 说明 |
|------|------|
| `src/mirror_of_wisdom/llm_cache.py` | LLM 响应缓存模块 |
| `src/mirror_of_wisdom/metrics.py` | 性能监控模块 |
| `src/mirror_of_wisdom/circuit_breaker.py` | 熔断器模块 |
| `.ai_temp/test_phase3_fixes.py` | Phase 3 P0/P1 优化验证测试 |
| `.ai_temp/test_phase3_p2.py` | Phase 3 P2 功能验证测试 |

### 7.2 修改文件

| 文件 | 变更内容 |
|------|----------|
| `src/mirror_of_wisdom/llm_client.py` | 集成缓存、监控、熔断器，修复异步阻塞，精细化重试 |
| `src/mirror_of_wisdom/config.py` | 超时默认值 30s → 90s |
| `.env.example` | 更新超时说明 |
| `.gitignore` | 添加 `.cache/` 目录 |

---

## 8. 上级顾问指导要点

### 8.1 关键洞察

1. **目标谬误修正**：在单次推理平均 13s 的物理限制下，设定"全局 <5s"目标是不切实际的。

2. **策略重心转移**：优化核心是**"规避"推理**而非"加速"推理。

3. **并发风险认知**：正因为等待时间长（13s+），async/await 阻塞问题变得更加致命。

4. **重试陷阱警示**：对"慢"进行超时重试极其危险，会导致请求在服务端积压。

### 8.2 技术方案调整

| 原计划 | 调整后 | 原因 |
|--------|--------|------|
| 超时 10s，强制完成 | 超时 90s，允许慢速 | 覆盖 72s 异常值 |
| 全局 <5s 响应 | 缓存 <50ms，冷启动 <90s | 承认物理限制 |
| 对所有错误重试 | 禁止 Timeout 重试 | 避免服务端积压 |
| 仅内存缓存 | 内存 + 持久化 | 重启后仍有效 |

---

## 9. 后续规划（Phase 4+）

### Phase 4: 高级功能（可选）

**目标**：增强用户体验

**功能**：
- 多轮对话支持
- 会话状态管理
- 用户自定义专家类型
- 提示词质量反馈机制

### Phase 5: 生态扩展（远期）

**目标**：构建提示词生态

**功能**：
- 提示词市场
- 社区贡献机制
- 专家模板共享
- A/B 测试框架

---

**文档创建时间**: 2025-01-22
**最后更新时间**: 2025-01-23
**状态**: **进行中**（P0/P1 已完成，P2 规划中）

---

**相关文档**：
- [Phase 2 验收报告](./ACCEPTANCE_Phase2.md)
- [Phase 2 对齐文档](./ALIGNMENT_Phase2.md)
- [项目 README](../../README.md)
