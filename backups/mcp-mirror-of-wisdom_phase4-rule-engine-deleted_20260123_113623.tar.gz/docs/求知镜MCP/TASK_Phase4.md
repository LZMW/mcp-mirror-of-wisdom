# TASK - Phase 4 架构重构任务拆分

> 阶段3: Atomize (原子化阶段)
> 创建时间: 2025-01-23
> 基于: DESIGN_Phase4.md
> 拆分原则: 原子化、可独立执行、明确依赖

---

## 1. 任务概览

### 1.1 任务分组

| 优先级 | 任务数量 | 预估时间 | 关键任务 |
|--------|---------|---------|---------|
| **P0** | 2 | 3小时 | 修改 create_expert_session, 验证 chat_with_expert |
| **P1** | 2 | 2小时 | 重命名 consult_mirror, 更新 server.py |
| **P2** | 2 | 2小时 | 增强 end_expert_session, 编写迁移指南 |
| **P3** | 4 | 10.5小时 | 更新文档, 编写测试, 运行验证 |
| **总计** | 10 | 17.5小时 | 包含缓冲时间 |

### 1.2 依赖关系图

```
批次1（可并行，6.5小时）：
├─ Task 1: 修改 create_expert_session ──────┐
├─ Task 2: 验证 chat_with_expert ───────────┤
├─ Task 3: 重命名 consult_mirror ──────────┤→ 基础功能完成
└─ Task 5: 增强 end_expert_session ────────┘

批次2（依赖批次1，2小时）：
├─ Task 4: 更新 server.py（依赖 Task 3）────┐→ 工具注册完成
└─ Task 6: 编写迁移指南（依赖 Task 1,3）───┘→ 文档完成

批次3（依赖批次1,2，5小时）：
├─ Task 7: 更新项目文档（依赖 1,3,5）──────┐→ 文档更新完成
└─ Task 8: 编写单元测试（依赖 1,2,3,5）───┘→ 测试代码完成

批次4（依赖批次3，2小时）：
└─ Task 9: 编写集成测试（依赖 Task 8）──────→ 集成测试完成

批次5（依赖批次4，2小时）：
└─ Task 10: 运行测试并修复（依赖 Task 9）──→ 全部通过
```

### 1.3 执行策略

**推荐：串行执行（简单可控）**
1. 批次1：核心功能修改（Task 1 → 2 → 3 → 5）
2. 批次2：后续工作（Task 4 → 6）
3. 批次3：文档和测试（Task 7 → 8）
4. 批次4：集成测试（Task 9）
5. 批次5：最终验证（Task 10）

---

## 2. P0 任务（核心）

### Task 1: 修改 create_expert_session 行为

**优先级**：🔴 P0
**预估时间**：2小时
**文件**：`src/tools/expert_session.py`
**函数**：`create_expert_session()`

#### 输入契约

**现有代码**：
```python
async def create_expert_session(params: CreateSessionInput) -> str:
    # 1. 生成专家提示词
    generation_result = await prompt_generator.generate_expert_prompt_with_meta(
        user_requirement=params.requirement
    )
    expert_prompt = generation_result["expert_prompt"]

    # 2. 创建会话
    session_id = await session_manager.create_session(
        system_prompt=expert_prompt,
        task_description=params.requirement
    )

    # 3. 返回确认
    return f"""✅ **专家会话已创建**
会话ID: {session_id}
...
"""
```

**可用资源**：
- `PromptGenerator.generate_expert_prompt_with_meta()`
- `SessionManager.create_session()`
- `SessionManager.update_session()`
- `LLMClient.generate_chat()`

#### 输出契约

**修改后的代码**：
```python
async def create_expert_session(params: CreateSessionInput) -> str:
    # 1. 生成专家提示词（内部，不返回）
    generation_result = await prompt_generator.generate_expert_prompt_with_meta(
        user_requirement=params.requirement
    )
    expert_prompt = generation_result["expert_prompt"]

    # 2. 创建会话
    session_id = await session_manager.create_session(
        system_prompt=expert_prompt,
        task_description=params.requirement
    )

    # 3. 【新增】生成专家首次回复
    messages = [
        {"role": "system", "content": expert_prompt},
        {
            "role": "user",
            "content": f"用户需求：{params.requirement}\n\n"
                      f"请主动询问细节以对齐信息粒度。"
        }
    ]
    expert_reply = await llm_client.generate_chat(messages=messages)

    # 4. 【新增】更新会话历史
    await session_manager.update_session(
        session_id=session_id,
        user_message=params.requirement,
        assistant_response=expert_reply
    )

    # 5. 返回 session_id + expert_reply
    return f"""✅ **专家会话已创建**

**会话ID**: `{session_id}`

**任务描述**: {params.requirement[:100]}{'...' if len(params.requirement) > 100 else ''}

**生成方法**: {generation_result["generation_method"]}

**质量评分**: {generation_result["quality_score"]:.2f}

---

## 📣 专家的首次回复

{expert_reply}

---

## 下一步

使用 `chat_with_expert` 工具继续对话：
```python
chat_with_expert(session_id="{session_id}", message="你的回复")
```
"""
```

#### 实施步骤

1. ✅ 阅读 `create_expert_session` 现有代码
2. ✅ 在创建会话后，构建首次对话的 messages
3. ✅ 调用 `llm_client.generate_chat()` 生成首次回复
4. ✅ 调用 `session_manager.update_session()` 更新历史
5. ✅ 修改返回格式，包含 expert_reply
6. ✅ 添加代码注释

#### 验收标准

- ✅ **功能**：返回的响应包含专家首次回复
- ✅ **机制**：expert_reply 基于 expert_prompt 生成
- ✅ **状态**：会话历史已更新（message_count = 2）
- ✅ **测试**：功能测试通过（手动或自动化）

#### 风险与注意事项

- ⚠️ 确保 LLM 调用失败时的错误处理
- ⚠️ 确认会话更新成功（message_count 正确）
- ⚠️ 验证 expert_reply 不包含 system prompt

---

### Task 2: 验证 chat_with_expert 实现

**优先级**：🔴 P0
**预估时间**：1小时
**文件**：`src/tools/expert_session.py`
**函数**：`chat_with_expert()`

#### 输入契约

**现有代码**（expert_session.py:239-371）：
```python
async def chat_with_expert(params: ChatInput) -> str:
    # 1. 加载会话
    session = await session_manager.get_session(params.session_id)

    # 2. 构建 LLM 请求
    messages = [
        {"role": "system", "content": session.system_prompt}
    ]
    history_context = session.get_conversation_context(max_messages=50)
    messages.extend(history_context)
    messages.append({"role": "user", "content": params.message})

    # 3. 调用 LLM
    response = await llm_client.generate_chat(messages=messages)

    # 4. 更新会话历史
    await session_manager.update_session(...)

    # 5. 返回专家回复
    return response
```

#### 输出契约

**验证报告**（Markdown 格式）：
```markdown
# chat_with_expert 验证报告

## 验证结果：✅ 通过 / ❌ 失败

## 验证项

### 1. System Prompt 注入
- [✅/❌] messages[0] = {"role": "system", "content": session.system_prompt}
- [✅/❌] system_prompt 来源于会话存储
- [✅/❌] system_prompt 未直接返回给用户

### 2. 对话历史管理
- [✅/❌] 历史消息正确添加到 messages
- [✅/❌] 最多包含 50 条历史消息
- [✅/❌] 新消息正确追加

### 3. LLM 调用
- [✅/❌] generate_chat() 接收完整 messages
- [✅/❌] 返回值只包含 assistant 消息

### 4. 会话更新
- [✅/❌] 会话历史正确更新
- [✅/❌] last_activity 时间戳更新

## 发现的问题

（如有问题，列出问题描述和位置）

## 结论

（总结验证结果）
```

#### 实施步骤

1. ✅ 阅读 `chat_with_expert` 完整代码
2. ✅ 验证 messages 构建逻辑
3. ✅ 确认 system_prompt 来源
4. ✅ 验证响应不包含 system prompt
5. ✅ 编写验证报告
6. ✅ 如发现问题，记录详细信息

#### 验收标准

- ✅ **确认**：system prompt 机制正确（或发现问题）
- ✅ **报告**：验证报告完整清晰
- ✅ **问题**：如有问题，详细记录位置和原因

#### 可能的结果

- ✅ **验证通过**：现有实现已正确，无需修改
- ❌ **发现问题**：需要修复（记录为新的任务）

---

## 3. P1 任务（重要）

### Task 3: 重命名 consult_mirror 为 start_expert_session

**优先级**：🟡 P1
**预估时间**：1.5小时
**文件**：`src/tools/consult_mirror.py`

#### 输入契约

**现有代码**（consult_mirror.py:177-290）：
```python
async def consult_mirror(params: ConsultMirrorInput) -> str:
    """
    根据用户指定的专家类型生成专家角色提示词。

    当前实现：返回专家提示词文本
    """
    # 生成专家信息
    expert_info = generate_expert_info(...)

    # 格式化输出
    return format_expert_prompt(...)
```

#### 输出契约

**修改后的代码**：
```python
async def start_expert_session(params: StartExpertSessionInput) -> str:
    """
    发起专家会话（Phase 4 重构）

    行为变更：
    - 不再返回专家提示词文本
    - 返回会话ID + 专家首次回复
    """
    # 1. 生成专家提示词（内部）
    expert_prompt = generate_expert_prompt(...)

    # 2. 创建会话
    session_id = await session_manager.create_session(
        system_prompt=expert_prompt
    )

    # 3. 生成首次回复
    expert_reply = await llm_client.generate_chat(...)

    # 4. 更新历史
    await session_manager.update_session(...)

    # 5. 返回首次回复
    return f"""..."""
```

#### 实施步骤

1. ✅ 重命名函数：`consult_mirror` → `start_expert_session`
2. ✅ 重命名输入模型：`ConsultMirrorInput` → `StartExpertSessionInput`
3. ✅ 调整函数行为：
   - 添加会话创建逻辑
   - 添加 LLM 调用生成首次回复
   - 调整返回格式
4. ✅ 更新文档字符串
5. ✅ 更新工具 annotations

#### 验收标准

- ✅ **重命名**：函数和模型重命名成功
- ✅ **行为**：返回会话ID + 专家首次回复
- ✅ **测试**：功能测试通过

---

### Task 4: 更新 server.py 工具注册

**优先级**：🟡 P1
**预估时间**：0.5小时
**文件**：`src/server.py`
**依赖**：Task 3

#### 输入契约

**现有代码**（server.py）：
```python
# 注册 consult_mirror 工具
@mcp.tool()
async def consult_mirror(
    expert_type: str,
    task_description: str,
    ...
) -> str:
    ...
```

#### 输出契约

**修改后的代码**：
```python
# 注册 start_expert_session 工具
@mcp.tool()
async def start_expert_session(
    requirement: str,
    expert_type: Optional[str] = None,
    ...
) -> str:
    ...

# 可选：保留旧工具并标记为 deprecated
@mcp.tool()
@deprecated("请使用 start_expert_session")
async def consult_mirror(...) -> str:
    ...
```

#### 实施步骤

1. ✅ 打开 `server.py`
2. ✅ 找到 `consult_mirror` 工具注册
3. ✅ 更新为 `start_expert_session`
4. ✅ 更新工具描述
5. ✅ 可选：添加 `@deprecated` 装饰器
6. ✅ 保存文件

#### 验收标准

- ✅ **注册**：工具注册更新成功
- ✅ **可见**：MCP Inspector 可以看到新工具
- ✅ **调用**：工具可以正常调用

---

## 4. P2 任务（优化）

### Task 5: 增强 end_expert_session

**优先级**：🟢 P2
**预估时间**：1小时
**文件**：`src/tools/expert_session.py`

#### 输入契约

**现有代码**（expert_session.py:374-463）：
```python
async def close_session(params: CloseSessionInput) -> str:
    # 1. 获取会话信息
    session_info = await session_manager.get_session_info(params.session_id)

    # 2. 关闭会话
    await session_manager.close_session(params.session_id)

    # 3. 返回确认
    return f"""✅ **会话已关闭**
...
"""
```

#### 输出契约

**修改后的代码**：
```python
async def end_expert_session(params: EndSessionInput) -> str:
    # 1. 获取会话信息
    session_info = await session_manager.get_session_info(params.session_id)

    # 2. 计算会话总结
    summary = {
        "dialogue_rounds": session_info['message_count'] // 2,
        "duration_minutes": calculate_duration(session_info),
        "expert_type": infer_expert_type(session_info),
        "resolved": True  # 可选：基于对话内容判断
    }

    # 3. 关闭会话
    await session_manager.close_session(params.session_id)

    # 4. 返回确认 + 总结
    return f"""✅ **会话已结束**

**会话ID**: `{params.session_id}`

**会话总结**:
- 对话轮次: {summary['dialogue_rounds']}
- 持续时间: {summary['duration_minutes']} 分钟
- 专家类型: {summary['expert_type']}
- 状态: {'✅ 已解决' if summary['resolved'] else '⏳ 进行中'}

---
感谢使用求知镜！
"""
```

#### 实施步骤

1. ✅ 重命名函数：`close_session` → `end_expert_session`
2. ✅ 重命名输入模型
3. ✅ 添加会话总结计算逻辑
4. ✅ 更新返回格式
5. ✅ 添加代码注释

#### 验收标准

- ✅ **重命名**：函数重命名成功
- ✅ **总结**：返回包含会话统计
- ✅ **关闭**：会话正确关闭

---

### Task 6: 编写迁移指南

**优先级**：🟢 P2
**预估时间**：1小时
**文件**：`docs/求知镜MCP/MIGRATION_Phase4.md`（新建）
**依赖**：Task 1, Task 3

#### 输入契约

- 新旧接口对比
- 代码示例
- 用户反馈

#### 输出契约

**文档结构**：
```markdown
# Phase 4 迁移指南

## 变更概述
简要说明 Phase 4 的核心变化

## 新旧接口对比

### consult_mirror → start_expert_session
| 维度 | 旧接口 (consult_mirror) | 新接口 (start_expert_session) |
|------|------------------------|-------------------------------|
| 返回内容 | 专家提示词文本 | 会话ID + 专家首次回复 |
| 参数 | expert_type, task_description | requirement, expert_type |
| 行为 | 单次返回 | 多轮对话 |

### close_session → end_expert_session
| 维度 | 旧接口 | 新接口 |
|------|--------|--------|
| 返回内容 | 关闭确认 | 关闭确认 + 会话总结 |

## 代码示例

### 旧用法
```python
result = await consult_mirror(
    expert_type="technical",
    task_description="优化数据库"
)
# 返回：专家提示词文本
```

### 新用法
```python
# Step 1: 发起会话
result = await start_expert_session(
    requirement="优化数据库",
    expert_type="technical"
)
# 返回：{session_id, expert_reply}

# Step 2: 继续对话
reply = await chat_with_expert(
    session_id=result["session_id"],
    message="PostgreSQL，100万用户"
)

# Step 3: 结束会话
summary = await end_expert_session(session_id=result["session_id"])
# 返回：会话总结
```

## 迁移检查清单
- [ ] 更新调用 consult_mirror 的代码
- [ ] 使用新的三步流程
- [ ] 处理会话ID管理
- [ ] 更新错误处理

## 常见问题

**Q: 旧接口还能用吗？**
A: 已标记为 deprecated，建议尽快迁移。

**Q: 如何获取专家提示词？**
A: Phase 4 不再返回提示词文本，专家角色在求知镜内部。

**Q: 会话ID如何管理？**
A: 会话ID由工具返回，需要本地AI存储和传递。
```

#### 实施步骤

1. ✅ 创建文档文件
2. ✅ 编写变更概述
3. ✅ 编写接口对比表
4. ✅ 编写代码示例
5. ✅ 编写迁移检查清单
6. ✅ 编写常见问题

#### 验收标准

- ✅ **完整**：文档内容完整
- ✅ **清晰**：示例代码可运行
- ✅ **实用**：用户可独立完成迁移

---

## 5. P3 任务（文档和测试）

### Task 7: 更新项目文档

**优先级**：🔵 P3
**预估时间**：2小时
**文件**：多个文档文件
**依赖**：Task 1, Task 3, Task 5

#### 输入契约

- Phase 4 所有代码变更
- 新接口定义
- 用户反馈

#### 输出契约

**需要更新的文档**：

1. **说明文档.md**
   - 更新 Phase 4 状态：从"待讨论" → "进行中" → "已完成"
   - 更新核心任务进度
   - 添加 Phase 4 进度记录

2. **README.md**
   - 更新使用示例（三步流程）
   - 更新核心特性描述
   - 添加 Phase 4 说明

3. **ARCHITECTURE_CLARIFICATION.md**
   - 更新实施状态
   - 标记已完成的部分

#### 实施步骤

1. ✅ 更新 `说明文档.md`
   - Phase 4 状态
   - 进度记录
   - 相关文档索引

2. ✅ 更新 `README.md`
   - 使用示例
   - 核心特性

3. ✅ 更新 `ARCHITECTURE_CLARIFICATION.md`
   - 实施状态
   - 完成标记

4. ✅ 检查所有文档一致性

#### 验收标准

- ✅ **完整**：所有文档更新完成
- ✅ **一致**：文档内容相互一致
- ✅ **准确**：无过时信息

---

### Task 8: 编写单元测试

**优先级**：🔵 P3
**预估时间**：3小时
**文件**：`tests/test_phase4.py`（新建）
**依赖**：Task 1, Task 2, Task 3, Task 5

#### 输入契约

- Phase 4 所有修改的代码
- 现有测试框架（pytest）

#### 输出契约

**测试文件结构**：
```python
# tests/test_phase4.py

import pytest
from mirror_of_wisdom.session_manager import get_session_manager
from tools.expert_session import create_expert_session, chat_with_expert, end_expert_session

class TestCreateExpertSession:
    """测试 create_expert_session 工具"""

    @pytest.mark.asyncio
    async def test_returns_session_id_and_first_reply(self):
        """测试返回会话ID和首次回复"""
        # Arrange
        params = CreateSessionInput(requirement="优化数据库")

        # Act
        result = await create_expert_session(params)

        # Assert
        assert "session_id" in result
        assert "expert_reply" in result
        assert len(result["expert_reply"]) > 0

    @pytest.mark.asyncio
    async def test_updates_session_history(self):
        """测试会话历史已更新"""
        # Arrange & Act
        params = CreateSessionInput(requirement="优化数据库")
        result = await create_expert_session(params)
        session_id = extract_session_id(result)

        # Assert
        session = await get_session_manager().get_session(session_id)
        assert session.message_count == 2  # user + assistant


class TestChatWithExpert:
    """测试 chat_with_expert 工具"""

    @pytest.mark.asyncio
    async def test_uses_system_prompt(self):
        """测试使用 system prompt"""
        # Arrange
        session_id = await create_test_session()
        params = ChatInput(session_id=session_id, message="测试消息")

        # Act
        reply = await chat_with_expert(params)

        # Assert
        assert len(reply) > 0
        # 验证 reply 基于 system prompt 生成

    @pytest.mark.asyncio
    async def test_system_prompt_not_leaked(self):
        """测试 system prompt 未泄露"""
        # Arrange & Act
        result = await chat_with_expert(...)

        # Assert
        assert "你是专家" not in result  # system prompt 内容


class TestEndExpertSession:
    """测试 end_expert_session 工具"""

    @pytest.mark.asyncio
    async def test_returns_summary(self):
        """测试返回会话总结"""
        # Arrange & Act
        result = await end_expert_session(...)

        # Assert
        assert "summary" in result
        assert "dialogue_rounds" in result["summary"]


class TestSystemPromptMechanism:
    """测试 system prompt 机制"""

    @pytest.mark.asyncio
    async def test_expert_role_consistency(self):
        """测试专家角色一致性"""
        # Arrange
        session_id = await create_test_session()

        # Act
        reply1 = await chat_with_expert(session_id, "问题1")
        reply2 = await chat_with_expert(session_id, "问题2")

        # Assert
        # 验证两次回复都基于同一 expert system prompt
        assert expert_role_consistent(reply1, reply2)

    @pytest.mark.asyncio
    async def test_concurrent_sessions(self):
        """测试并发会话"""
        # Arrange & Act
        session1 = await create_test_session(expert_type="technical")
        session2 = await create_test_session(expert_type="creative")

        reply1 = await chat_with_expert(session1, "技术问题")
        reply2 = await chat_with_expert(session2, "创意问题")

        # Assert
        assert is_technical_reply(reply1)
        assert is_creative_reply(reply2)
```

#### 实施步骤

1. ✅ 创建测试文件
2. ✅ 编写 `create_expert_session` 测试
3. ✅ 编写 `chat_with_expert` 测试
4. ✅ 编写 `end_expert_session` 测试
5. ✅ 编写 `system_prompt` 机制测试
6. ✅ 运行测试并修复
7. ✅ 检查覆盖率

#### 验收标准

- ✅ **覆盖**：覆盖率 > 80%
- ✅ **通过**：所有测试通过
- ✅ **文档**：测试文档清晰

---

### Task 9: 编写集成测试

**优先级**：🔵 P3
**预估时间**：2小时
**文件**：`tests/integration/test_phase4_integration.py`（新建）
**依赖**：Task 8

#### 输入契约

- 完整的功能实现
- 单元测试通过

#### 输出契约

**集成测试场景**：

```python
# tests/integration/test_phase4_integration.py

@pytest.mark.asyncio
async def test_complete_session_flow():
    """测试完整会话流程"""
    # Step 1: 创建会话
    result = await start_expert_session(requirement="优化数据库")
    session_id = extract_session_id(result)

    # 验证
    assert "expert_reply" in result
    assert "请提供" in result["expert_reply"]  # 信息粒度对齐

    # Step 2: 继续对话
    reply = await chat_with_expert(
        session_id=session_id,
        message="PostgreSQL，100万用户"
    )

    # 验证
    assert len(reply) > 0
    assert "PostgreSQL" in reply or "索引" in reply

    # Step 3: 再次对话
    reply2 = await chat_with_expert(
        session_id=session_id,
        message="具体怎么做？"
    )

    # 验证
    assert len(reply2) > 0

    # Step 4: 结束会话
    summary = await end_expert_session(session_id=session_id)

    # 验证
    assert "summary" in summary
    assert summary["summary"]["dialogue_rounds"] >= 2


@pytest.mark.asyncio
async def test_error_session_not_found():
    """测试会话不存在的错误处理"""
    with pytest.raises(ValueError) as exc_info:
        await chat_with_expert(
            session_id="invalid-id",
            message="测试"
        )

    assert "不存在" in str(exc_info.value)


@pytest.mark.asyncio
async def test_concurrent_multiple_sessions():
    """测试多会话并发"""
    sessions = []

    # 创建多个会话
    for i in range(5):
        result = await start_expert_session(requirement=f"问题{i}")
        session_id = extract_session_id(result)
        sessions.append(session_id)

    # 并发对话
    replies = await asyncio.gather(*[
        chat_with_expert(session_id=s, message=f"消息{i}")
        for i, s in enumerate(sessions)
    ])

    # 验证
    assert len(replies) == 5
    for reply in replies:
        assert len(reply) > 0

    # 清理
    for session_id in sessions:
        await end_expert_session(session_id=session_id)
```

#### 实施步骤

1. ✅ 创建集成测试文件
2. ✅ 编写完整流程测试
3. ✅ 编写错误场景测试
4. ✅ 编写并发场景测试
5. ✅ 运行并修复

#### 验收标准

- ✅ **场景**：覆盖主要场景
- ✅ **通过**：所有测试通过
- ✅ **端到端**：完整验证

---

### Task 10: 运行完整测试并修复问题

**优先级**：🔵 P3
**预估时间**：2小时
**依赖**：Task 9

#### 输入契约

- 所有测试代码
- 完整的功能实现

#### 输出契约

**测试报告**：
```markdown
# Phase 4 测试报告

## 测试执行日期
2025-01-23

## 测试结果总览
- 单元测试：25/25 通过 ✅
- 集成测试：5/5 通过 ✅
- 回归测试（Phase 1-3）：通过 ✅
- 总计：100% 通过率

## 单元测试详情
| 测试套件 | 测试数量 | 通过 | 失败 | 覆盖率 |
|---------|---------|------|------|--------|
| TestCreateExpertSession | 5 | 5 | 0 | 85% |
| TestChatWithExpert | 8 | 8 | 0 | 90% |
| TestEndExpertSession | 3 | 3 | 0 | 80% |
| TestSystemPromptMechanism | 9 | 9 | 0 | 95% |

## 集成测试详情
| 测试场景 | 状态 | 说明 |
|---------|------|------|
| 完整会话流程 | ✅ | 三步流程验证 |
| 会话不存在错误 | ✅ | 错误处理正确 |
| 多会话并发 | ✅ | 并发安全 |
| LLM失败降级 | ✅ | 降级策略生效 |
| 会话过期清理 | ✅ | TTL机制正确 |

## 回归测试
| Phase | 测试数量 | 通过 | 失败 |
|-------|---------|------|------|
| Phase 1 | 22 | 22 | 0 |
| Phase 2 | 15 | 15 | 0 |
| Phase 3 | 7 | 7 | 0 |

## 发现的问题与修复
（记录测试中发现的问题和修复措施）

## 性能测试
- 平均响应时间：85ms ✅
- 缓存命中率：75% ✅
- 并发会话数：100+ ✅

## 结论
✅ Phase 4 架构重构验证通过，可以交付。
```

#### 实施步骤

1. ✅ 运行所有单元测试
   ```bash
   pytest tests/test_phase4.py -v --cov
   ```

2. ✅ 运行所有集成测试
   ```bash
   pytest tests/integration/test_phase4_integration.py -v
   ```

3. ✅ 运行回归测试
   ```bash
   pytest tests/ -v
   ```

4. ✅ 记录失败的测试

5. ✅ 修复发现的问题
   - 分析失败原因
   - 修复代码
   - 重新运行测试

6. ✅ 生成测试报告

7. ✅ 验证性能指标

#### 验收标准

- ✅ **单元**：100% 通过
- ✅ **集成**：100% 通过
- ✅ **回归**：100% 通过
- ✅ **性能**：符合目标
- ✅ **Bug**：无已知 Bug

---

## 6. 任务依赖图（Mermaid）

```mermaid
graph TD
    T1[Task 1: 修改 create_expert_session]
    T2[Task 2: 验证 chat_with_expert]
    T3[Task 3: 重命名 consult_mirror]
    T5[Task 5: 增强 end_expert_session]

    T4[Task 4: 更新 server.py]
    T6[Task 6: 编写迁移指南]

    T7[Task 7: 更新项目文档]
    T8[Task 8: 编写单元测试]

    T9[Task 9: 编写集成测试]
    T10[Task 10: 运行测试并修复]

    T3 --> T4
    T1 & T3 --> T6
    T1 & T2 & T3 & T5 --> T7
    T1 & T2 & T3 & T5 --> T8
    T8 --> T9
    T9 --> T10

    style T1 fill:#ff6b6b
    style T2 fill:#ff6b6b
    style T3 fill:#ffd93d
    style T4 fill:#ffd93d
    style T5 fill:#6bcf7f
    style T6 fill:#6bcf7f
    style T7 fill:#4d96ff
    style T8 fill:#4d96ff
    style T9 fill:#4d96ff
    style T10 fill:#4d96ff
```

---

## 7. 执行检查清单

### 批次1：核心功能修改（6.5小时）

- [ ] Task 1: 修改 create_expert_session（2h）
- [ ] Task 2: 验证 chat_with_expert（1h）
- [ ] Task 3: 重命名 consult_mirror（1.5h）
- [ ] Task 5: 增强 end_expert_session（1h）
- [ ] 批次验收：核心功能可用

### 批次2：后续工作（2小时）

- [ ] Task 4: 更新 server.py（0.5h）
- [ ] Task 6: 编写迁移指南（1h）
- [ ] 批次验收：工具注册和文档完成

### 批次3：文档和测试（5小时）

- [ ] Task 7: 更新项目文档（2h）
- [ ] Task 8: 编写单元测试（3h）
- [ ] 批次验收：文档和测试代码完成

### 批次4：集成测试（2小时）

- [ ] Task 9: 编写集成测试（2h）
- [ ] 批次验收：集成测试通过

### 批次5：最终验证（2小时）

- [ ] Task 10: 运行测试并修复（2h）
- [ ] 最终验收：所有测试通过，无 Bug

---

## 8. 风险管理

### 高风险任务

| 任务 | 风险 | 缓解措施 |
|------|------|---------|
| Task 1 | LLM调用失败处理 | 完善错误处理和降级策略 |
| Task 3 | 破坏现有功能 | 保留旧接口，标记 deprecated |
| Task 8 | 测试覆盖不足 | 参考现有测试，确保覆盖率 |
| Task 10 | 遗留 Bug | 充分测试，逐步修复 |

### 进度风险

| 风险 | 影响 | 应对 |
|------|------|------|
| 任务超时 | 延期交付 | 按优先级调整，P0必须完成 |
| 依赖阻塞 | 无法继续 | 优先解决依赖，必要时调整顺序 |
| 测试失败 | 质量不达标 | 预留充足调试时间 |

---

## 9. 验收标准总览

### 功能验收

- ✅ `start_expert_session` 返回首次回复
- ✅ `create_expert_session` 返回首次回复
- ✅ `chat_with_expert` 正确使用 system prompt
- ✅ `end_expert_session` 返回会话总结
- ✅ System prompt 不泄露
- ✅ 多轮对话保持角色一致性

### 质量验收

- ✅ 代码风格符合规范
- ✅ 函数注释完整
- ✅ 单元测试覆盖率 > 80%
- ✅ 所有测试通过

### 性能验收

- ✅ 工具响应时间 < 100ms
- ✅ Phase 3 优化仍然有效
- ✅ 缓存命中率 > 70%

### 文档验收

- ✅ 迁移指南完整
- ✅ 项目文档更新
- ✅ 代码注释完善

---

## 10. 附录

### 10.1 任务状态跟踪

| 任务 | 负责人 | 状态 | 开始时间 | 完成时间 | 实际用时 |
|------|--------|------|---------|---------|---------|
| Task 1 | AI | 待开始 | - | - | - |
| Task 2 | AI | 待开始 | - | - | - |
| ... | ... | ... | ... | ... | ... |

### 10.2 术语表

- **System Prompt**: LLM API 中 role="system" 的消息
- **专家内部化**: 专家提示词仅在求知镜内部使用
- **信息粒度对齐**: 专家主动询问细节，确保理解需求
- **零上下文污染**: 本地AI上下文不包含专家提示词

### 10.3 参考资料

- `DESIGN_Phase4.md` - 架构设计文档
- `ALIGNMENT_Phase4.md` - 需求对齐文档
- `ARCHITECTURE_CLARIFICATION.md` - 架构澄清文档
- `src/tools/expert_session.py` - 核心工具实现
- `src/tools/consult_mirror.py` - 待重构工具

---

**文档创建人**：AI 开发团队
**创建时间**：2025-01-23
**状态**：✅ Atomize 阶段完成
**下一步**：Approve 阶段 - 方案审批
