"""提示词生成器模块

仅支持元提示词模式（Phase 2）：使用4D流程生成专家提示词

⚠️ 规则引擎模式已删除（Phase 4 架构重构）
"""

import json
import logging
from pathlib import Path
from typing import Literal, Optional

from .llm_client import get_llm_client
from .config import get_mirror_config, get_server_config

logger = logging.getLogger(__name__)


# ============================================================================
# 元提示词（Meta-Prompt）- Phase 2 核心功能
# ============================================================================

META_PROMPT = """# Role
你是一位精通提示工程的专家 AI（求知镜）。你的任务是接收我（本地ai）的原始需求，并将其转化为一个结构严谨、效果卓越的专家级提示词。

# Workflow (思维处理流程)
在生成最终提示词之前，请务必在后台严格执行以下 **4D 流程** 对我（本地ai）的需求进行处理：

1.  **Deconstruction (解构分析)**：提取核心意图、关键要素、背景信息；确定输出要求与限制。
2.  **Diagnosis (问题诊断)**：检查清晰度差距；验证具体性/完整性；评估结构需求与平台适配性。
3.  **Development (方案开发)**：选择最佳技术（COT/Few-Shot等）；分配合适角色；构建逻辑结构并注入约束。
4.  **Delivery (成果交付)**：格式化最终提示；进行逻辑与完整性校验；提供使用指导。

# Constraints (关键约束)
*   **E_2 规则**：在构建约束条件时，必须执行 "[E]xplicit constraints"，即明确包含否定约束（禁止项、排除条件）。
*   **输出格式**：不要解释 4D 流程的具体内容，直接输出优化后的提示词。最终输出必须严格遵守下方的 Markdown 模板。

# Output Template (输出模板)

```markdown
# 1. 背景 (Context)
[详细描述任务环境、当前遇到的问题及具体的输入数据]

# 2. 目标 (Objective)
[核心指令，包含预期达成的深度洞察和具体行动]

# 3. 风格与语调 (Style & Tone)
*   **风格**: [具体的写作/编码风格，设定内容的人格特征及吸引点]
*   **语调**: [情感色彩，包含心理距离及共情水平]

# 4. 受众 (Audience)
[受众画像，明确其核心痛点与心理预期]

# 5. 响应 (Response)
## 5.1 执行步骤 (Steps)
[逻辑清晰的执行路径]
## 5.2 评估标准 (Evaluation)
[可量化的质量验收指标]
## 5.3 格式与约束
[输出格式 + 明确包含否定约束（禁止项、排除条件）]
```

# Input (用户需求)
{user_input}

请严格按照上述模板生成专家提示词：
"""



class PromptGenerator:
    """提示词生成器（仅元提示词模式）"""

    def __init__(self):
        """初始化提示词生成器"""
        self.llm_client = get_llm_client()
        self.config = get_mirror_config()
        self.server_config = get_server_config()

    async def generate_expert_prompt_with_meta(
        self,
        user_requirement: str
    ) -> dict:
        """
        使用元提示词生成专家提示词（Phase 2 核心功能）

        这是求知镜的核心功能：
        1. 接收本地AI的原始需求
        2. 使用元提示词（4D流程）生成专家提示词
        3. 返回生成的专家提示词，用于后续会话

        Args:
            user_requirement: 本地AI的原始需求描述

        Returns:
            包含以下字段的字典：
            - expert_prompt: 生成的专家提示词（Markdown格式）
            - task_description: 原始任务描述
            - generation_method: "meta_prompt"（生成方法标识）
            - quality_score: 质量评分
            - timestamp: 生成时间戳
        """
        logger.info(f"使用元提示词生成专家提示词: {len(user_requirement)} 字符")

        try:
            # 构建元提示词请求
            meta_prompt_request = META_PROMPT.format(user_input=user_requirement)

            # 调用LLM生成专家提示词
            response = await self.llm_client.generate(
                prompt=meta_prompt_request,
                response_format="text"  # 元提示词输出Markdown文本
            )

            # 清理响应（移除可能的markdown代码块标记）
            response = response.strip()
            if response.startswith("```markdown"):
                response = response[11:]
            if response.startswith("```"):
                response = response[3:]
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()

            # 记录生成的提示词长度
            prompt_length = len(response)
            logger.info(f"元提示词生成完成: {prompt_length} 字符")

            # 返回结果
            result = {
                "expert_prompt": response,
                "task_description": user_requirement,
                "generation_method": "meta_prompt",
                "quality_score": 1.0,  # 元提示词生成默认高质量
                "timestamp": __import__("datetime").datetime.now().isoformat()
            }

            return result

        except Exception as e:
            logger.error(f"元提示词生成失败: {e}")
            # 回退到静态通用助手提示词
            logger.warning("回退到静态通用助手模式")

            # 静态兜底提示词（通用助手）
            fallback_prompt = f"""# 通用AI助手

## 任务背景
{user_requirement}

## 专家角色设定
你是一位知识渊博、乐于助人的AI助手。你具备：
- 跨学科知识整合能力
- 清晰的逻辑思维
- 友好耐心的沟通风格
- 灵活适应不同需求的能力

## 工作原则
1. 仔细理解用户的需求
2. 提供全面准确的回答
3. 承认知识的局限性
4. 引导用户深入思考

现在请以通用AI助手的身份，针对上述任务提供帮助。
"""

            return {
                "expert_prompt": fallback_prompt,
                "task_description": user_requirement,
                "generation_method": "static_fallback",
                "quality_score": 0.7,
                "timestamp": __import__("datetime").datetime.now().isoformat(),
                "fallback": True,
                "error": str(e)
            }


# 全局实例
_generator: PromptGenerator | None = None


def get_prompt_generator() -> PromptGenerator:
    """获取提示词生成器实例"""
    global _generator
    if _generator is None:
        _generator = PromptGenerator()
    return _generator


def reset_generator():
    """重置生成器（主要用于测试）"""
    global _generator
    _generator = None
