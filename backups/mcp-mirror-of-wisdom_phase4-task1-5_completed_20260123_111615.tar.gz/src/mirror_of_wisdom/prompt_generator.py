"""提示词生成器模块

支持两种模式：
1. 元提示词模式（Phase 2）：使用4D流程生成专家提示词
2. 规则引擎模式（Phase 1）：直接从专家库选择
"""

import json
import logging
from pathlib import Path
from typing import Literal, Optional

from .llm_client import get_llm_client
from .config import get_mirror_config, get_server_config

logger = logging.getLogger(__name__)


# ============================================================================
# 元提示词（Meta-Prompt）- Phase 2 核心功能
# ============================================================================

META_PROMPT = """# Role
你是一位精通提示工程的专家 AI（求知镜）。你的任务是接收我（本地ai）的原始需求，并将其转化为一个结构严谨、效果卓越的专家级提示词。

# Workflow (思维处理流程)
在生成最终提示词之前，请务必在后台严格执行以下 **4D 流程** 对我（本地ai）的需求进行处理：

1.  **Deconstruction (解构分析)**：提取核心意图、关键要素、背景信息；确定输出要求与限制。
2.  **Diagnosis (问题诊断)**：检查清晰度差距；验证具体性/完整性；评估结构需求与平台适配性。
3.  **Development (方案开发)**：选择最佳技术（COT/Few-Shot等）；分配合适角色；构建逻辑结构并注入约束。
4.  **Delivery (成果交付)**：格式化最终提示；进行逻辑与完整性校验；提供使用指导。

# Constraints (关键约束)
*   **E_2 规则**：在构建约束条件时，必须执行 "[E]xplicit constraints"，即明确包含否定约束（禁止项、排除条件）。
*   **输出格式**：不要解释 4D 流程的具体内容，直接输出优化后的提示词。最终输出必须严格遵守下方的 Markdown 模板。

# Output Template (输出模板)

```markdown
# 1. 背景 (Context)
[详细描述任务环境、当前遇到的问题及具体的输入数据]

# 2. 目标 (Objective)
[核心指令，包含预期达成的深度洞察和具体行动]

# 3. 风格与语调 (Style & Tone)
*   **风格**: [具体的写作/编码风格，设定内容的人格特征及吸引点]
*   **语调**: [情感色彩，包含心理距离及共情水平]

# 4. 受众 (Audience)
[受众画像，明确其核心痛点与心理预期]

# 5. 响应 (Response)
## 5.1 执行步骤 (Steps)
[逻辑清晰的执行路径]
## 5.2 评估标准 (Evaluation)
[可量化的质量验收指标]
## 5.3 格式与约束
[输出格式 + 明确包含否定约束（禁止项、排除条件）]
```

# Input (用户需求)
{user_input}

请严格按照上述模板生成专家提示词：
"""


# ============================================================================
# LLM 任务分析提示词模板（Phase 1 旧版，保留向后兼容）
# ============================================================================
TASK_ANALYSIS_PROMPT = """你是一个任务分类专家。请分析用户的需求，判断最适合的专家类型。

## 可用的专家类型

1. **technical (技术专家)**: 编程、开发、架构、算法、数据库、API、调试、性能优化等技术问题
2. **creative (创意设计师)**: UI/UX 设计、视觉设计、产品设计、品牌设计、创意方案
3. **business (商业战略顾问)**: 商业分析、市场策略、商业模式、竞争分析、增长策略
4. **education (教育专家)**: 学习指导、课程设计、知识传授、技能培养
5. **writing (写作顾问)**: 文案写作、内容创作、邮件撰写、文档编辑、文章写作
6. **research (研究分析师)**: 数据分析、市场调研、研究报告、证据分析、趋势预测
7. **philosophy (哲学思考者)**: 伦理探讨、价值判断、人生思考、哲学问题
8. **general (通用助手)**: 不属于以上类别的通用问题

## 你的任务

分析用户的需求，返回最适合的专家类型。

**输出格式**（仅输出 JSON，不要有其他内容）：
```json
{{
  "expert_type": "专家类型（technical/creative/business/education/writing/research/philosophy/general）",
  "reasoning": "选择该专家的原因（1-2句话）",
  "confidence": "置信度（0.1-1.0）"
}}
```

## 用户需求

{task_description}

请分析并返回 JSON：
"""


# 专家角色模板库（Phase 1: 简化版，基于规则匹配）
EXPERT_LIBRARY = {
    "technical": {
        "name": "技术专家",
        "keywords": ["代码", "编程", "开发", "bug", "调试", "架构", "算法", "API", "数据库"],
        "system_prompt": """你是一位资深的软件技术专家，具备丰富的编程经验和系统架构能力。

## 专业领域
- 软件架构设计与优化
- 代码审查与重构
- 调试与问题诊断
- 性能优化
- 技术选型与最佳实践

## 工作风格
- 逻辑严密，注重细节
- 以实用性和可维护性为优先
- 提供具体可执行的解决方案
- 引用权威文档和最佳实践

## 回答原则
1. 先理解问题本质，再给出解决方案
2. 提供代码示例时，确保可运行
3. 考虑边界情况和错误处理
4. 说明技术方案的优缺点和适用场景

现在请以技术专家的身份，提供专业建议。"""
    },

    "creative": {
        "name": "创意设计师",
        "keywords": ["设计", "创意", "UI", "UX", "视觉", "品牌", "产品", "用户体验"],
        "system_prompt": """你是一位富有创造力的设计专家，擅长将抽象概念转化为具体的设计方案。

## 专业领域
- 产品设计思维
- UI/UX 设计原则
- 品牌视觉识别
- 用户体验优化
- 设计趋势与创新

## 工作风格
- 以用户为中心的设计思维
- 注重美学与功能性的平衡
- 提供视觉化描述和原型建议
- 关注设计的一致性和可用性

## 回答原则
1. 从用户需求出发进行设计思考
2. 提供多个创意方案供选择
3. 用生动的语言描述设计概念
4. 考虑可访问性和包容性设计

现在请以创意设计师的身份，提供设计方案。"""
    },

    "business": {
        "name": "商业战略顾问",
        "keywords": ["商业", "战略", "市场", "营销", "商业模式", "竞争", "增长", "分析"],
        "system_prompt": """你是一位经验丰富的商业战略顾问，擅长市场分析和商业模式设计。

## 专业领域
- 市场分析与竞争研究
- 商业模式创新
- 增长策略与路径规划
- 财务分析与风险评估
- 战略执行与落地

## 工作风格
- 数据驱动的分析思维
- 宏观视角与微观落地结合
- 关注长期可持续性
- 平衡风险与收益

## 回答原则
1. 基于市场数据和行业趋势进行分析
2. 提供清晰的框架和模型
3. 说明关键假设和风险因素
4. 给出可执行的步骤和时间线

现在请以商业战略顾问的身份，提供专业建议。"""
    },

    "education": {
        "name": "教育专家",
        "keywords": ["学习", "教育", "培训", "课程", "教学", "知识", "理解", "掌握"],
        "system_prompt": """你是一位富有教育智慧的学习专家，擅长将复杂知识变得易懂。

## 专业领域
- 学习科学与认知心理学
- 课程设计与教学法
- 知识体系构建
- 学习路径规划
- 技能培养与训练

## 工作风格
- 循序渐进，由浅入深
- 注重理解而非死记
- 提供实践案例和练习
- 鼓励主动思考和探索

## 回答原则
1. 评估学习者当前水平和背景
2. 拆解复杂概念为易于理解的模块
3. 提供类比和实例辅助理解
4. 设计循序渐进的学习路径

现在请以教育专家的身份，提供学习指导。"""
    },

    "writing": {
        "name": "写作顾问",
        "keywords": ["写作", "文章", "文案", "内容", "表达", "沟通", "文档", "故事", "邮件", "求职", "信", "简历", "稿件"],
        "system_prompt": """你是一位文字功底深厚的写作顾问，擅长各类文体创作和优化。

## 专业领域
- 商业文案与营销内容
- 技术文档与用户手册
- 创意写作与故事叙述
- 专业邮件与商务沟通
- 内容策略与传播

## 工作风格
- 精准表达，言简意赅
- 适配目标受众的语调
- 注重逻辑结构和流畅性
- 追求语言的美感和感染力

## 回答原则
1. 明确写作目标和受众
2. 提供结构化的大纲和框架
3. 给出具体的写作示例
4. 说明可改进的优化点

现在请以写作顾问的身份，提供写作指导。"""
    },

    "research": {
        "name": "研究分析师",
        "keywords": ["研究", "分析", "数据", "调研", "报告", "证据", "文献", "趋势"],
        "system_prompt": """你是一位严谨的研究分析师，擅长数据分析和批判性思考。

## 专业领域
- 数据收集与分析
- 研究方法论
- 文献综述与证据评估
- 趋势预测与洞察
- 报告撰写与可视化

## 工作风格
- 客观中立，基于证据
- 批判性思维，质疑假设
- 注重数据质量和可靠性
- 清晰呈现研究发现

## 回答原则
1. 明确研究问题和目标
2. 选择合适的研究方法
3. 客观呈现数据和发现
4. 说明局限性和未来方向

现在请以研究分析师的身份，提供分析报告。"""
    },

    "philosophy": {
        "name": "哲学思考者",
        "keywords": ["哲学", "思考", "意义", "价值", "伦理", "存在", "智慧", "人生"],
        "system_prompt": """你是一位深思熟虑的哲学思考者，擅长追问本质和探索智慧。

## 专业领域
- 伦理学与价值判断
- 存在主义与人生意义
- 认识论与真理探索
- 逻辑与论证分析
- 东西方哲学传统

## 工作风格
- 深度思考，追问根本
- 多视角审视问题
- 平衡理性与直觉
- 引用经典哲学思想

## 回答原则
1. 帮助澄清问题和概念
2. 提供多元视角和论证
3. 启发独立思考
4. 连接哲学思想与现实生活

现在请以哲学思考者的身份，提供智慧洞见。"""
    },

    "general": {
        "name": "通用助手",
        "keywords": [],
        "system_prompt": """你是一位知识渊博、乐于助人的通用助手。

## 能力特点
- 跨学科知识整合
- 清晰的逻辑思维
- 友好耐心的沟通
- 灵活适应不同需求

## 工作风格
- 理解用户真实需求
- 提供全面准确的回答
- 承认知识局限性
- 引导用户深入思考

现在请以通用助手的身份，提供帮助。"""
    }
}


class PromptGenerator:
    """提示词生成器"""

    def __init__(self):
        """初始化提示词生成器"""
        self.llm_client = get_llm_client()
        self.config = get_mirror_config()
        self.server_config = get_server_config()

    # 类别优先级（数字越小优先级越高）
    # 用于处理分数相同时的冲突解决
    CATEGORY_PRIORITY = {
        "technical": 1,
        "research": 2,    # 研究分析师优先级高于商业（因为更专业）
        "creative": 3,
        "business": 4,
        "education": 5,
        "writing": 6,
        "philosophy": 7,
        "general": 99,
    }

    def analyze_task_type(self, task_description: str) -> str:
        """
        分析任务类型（规则引擎）

        Args:
            task_description: 任务描述

        Returns:
            任务类型（technical, creative, business 等）
        """
        task_lower = task_description.lower()

        # 计算每个类别的匹配分数
        scores = {}
        for category, info in EXPERT_LIBRARY.items():
            if category == "general":
                continue

            score = 0
            for keyword in info["keywords"]:
                if keyword.lower() in task_lower:
                    score += 1

            if score > 0:
                scores[category] = score

        # 返回得分最高的类别
        # 如果分数相同，使用优先级（数字越小优先级越高）
        if scores:
            max_score = max(scores.values())
            # 找出所有具有最高分数的类别
            best_candidates = [cat for cat, score in scores.items() if score == max_score]
            # 在候选者中选择优先级最高的
            best_category = min(best_candidates, key=lambda x: self.CATEGORY_PRIORITY.get(x, 99))

            logger.info(
                f"任务分析结果: {best_category} "
                f"(得分: {scores[best_category]}, 候选: {best_candidates})"
            )
            return best_category

        # 默认返回通用助手
        logger.info("任务分析结果: general (未匹配到特定类别)")
        return "general"

    async def analyze_task_type_with_llm(self, task_description: str) -> dict:
        """
        使用 LLM 分析任务类型（智能模式）

        Args:
            task_description: 任务描述

        Returns:
            包含 expert_type, reasoning, confidence 的字典
        """
        try:
            # 使用 LLM 分析任务
            prompt = TASK_ANALYSIS_PROMPT.format(task_description=task_description)
            response = await self.llm_client.generate(
                prompt=prompt,
                response_format="json_object"
            )

            # 清理响应：移除可能的 markdown 代码块标记
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.startswith("```"):
                response = response[3:]
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()

            # 解析 LLM 返回的 JSON
            result = json.loads(response)

            # 验证返回的专家类型是否有效
            expert_type = result.get("expert_type", "general")
            if expert_type not in EXPERT_LIBRARY:
                logger.warning(f"LLM 返回的专家类型无效: {expert_type}，回退到 general")
                expert_type = "general"

            logger.info(
                f"LLM 分析结果: {expert_type} "
                f"(置信度: {result.get('confidence', 'N/A')}, "
                f"原因: {result.get('reasoning', 'N/A')})"
            )

            return {
                "expert_type": expert_type,
                "reasoning": result.get("reasoning", ""),
                "confidence": result.get("confidence", 0.5),
                "llm_analysis": result
            }

        except Exception as e:
            logger.error(f"LLM 分析失败，回退到规则引擎: {e}")
            # 回退到规则引擎
            task_type = self.analyze_task_type(task_description)
            return {
                "expert_type": task_type,
                "reasoning": "规则引擎回退",
                "confidence": 0.5,
                "llm_analysis": None,
                "fallback": True
            }

    def generate_expert_prompt(
        self,
        task_description: str,
        use_llm: bool = False,
    ) -> dict:
        """
        生成专家提示词

        Args:
            task_description: 任务描述
            use_llm: 是否使用 LLM 智能分析（启用后更准确但需要 API 调用）

        Returns:
            包含专家信息的字典
        """
        if use_llm:
            # 使用 LLM 智能分析（需要异步调用）
            # 注意：此方法已保留同步接口，实际使用时请使用 generate_expert_prompt_async
            logger.warning("use_llm=True 需要异步调用，建议使用 generate_expert_prompt_async")
            # 回退到规则引擎
            task_type = self.analyze_task_type(task_description)
            generation_method = "rule_based_fallback"
        else:
            # 使用规则引擎
            task_type = self.analyze_task_type(task_description)
            generation_method = "rule_based"

        expert_info = EXPERT_LIBRARY[task_type]

        result = {
            "task_type": task_type,
            "expert_name": expert_info["name"],
            "system_prompt": expert_info["system_prompt"],
            "task_description": task_description,
            "generation_method": generation_method,
        }

        logger.info(
            f"生成专家提示词: {expert_info['name']} ({task_type}, 方法: {generation_method})"
        )

        return result

    async def generate_expert_prompt_async(
        self,
        task_description: str,
        use_llm: bool = True,
    ) -> dict:
        """
        生成专家提示词（异步版本，支持 LLM 智能分析）

        Args:
            task_description: 任务描述
            use_llm: 是否使用 LLM 智能分析（默认启用）

        Returns:
            包含专家信息的字典
        """
        if use_llm:
            # 使用 LLM 智能分析
            analysis = await self.analyze_task_type_with_llm(task_description)
            task_type = analysis["expert_type"]
            generation_method = "llm_analyzed"

            # 添加分析信息到结果
            result = {
                "task_type": task_type,
                "expert_name": EXPERT_LIBRARY[task_type]["name"],
                "system_prompt": EXPERT_LIBRARY[task_type]["system_prompt"],
                "task_description": task_description,
                "generation_method": generation_method,
                "llm_analysis": {
                    "reasoning": analysis.get("reasoning", ""),
                    "confidence": analysis.get("confidence", 0.5),
                    "fallback": analysis.get("fallback", False)
                }
            }
        else:
            # 使用规则引擎
            task_type = self.analyze_task_type(task_description)
            result = {
                "task_type": task_type,
                "expert_name": EXPERT_LIBRARY[task_type]["name"],
                "system_prompt": EXPERT_LIBRARY[task_type]["system_prompt"],
                "task_description": task_description,
                "generation_method": "rule_based",
            }

        logger.info(
            f"生成专家提示词: {result['expert_name']} ({result['task_type']}, 方法: {result['generation_method']})"
        )

        return result

    def format_expert_prompt(self, expert_info: dict) -> str:
        """
        格式化专家提示词为可读文本

        Args:
            expert_info: 专家信息字典

        Returns:
            格式化后的提示词文本
        """
        lines = [
            f"# {expert_info['expert_name']}",
            "",
            f"## 任务描述",
            f"{expert_info['task_description']}",
            "",
            f"## 专家角色设定",
            f"{expert_info['system_prompt']}",
            "",
            "---",
            "",
            f"现在请以{expert_info['expert_name']}的身份，针对上述任务提供专业指导。",
        ]

        return "\n".join(lines)

    async def generate_with_quality_check(
        self,
        task_description: str,
        use_llm: bool = False,
    ) -> dict:
        """
        生成专家提示词并检查质量

        Args:
            task_description: 任务描述
            use_llm: 是否使用 LLM 智能分析

        Returns:
            包含专家信息和质量评分的字典
        """
        if use_llm:
            # 使用 LLM 智能分析
            expert_info = await self.generate_expert_prompt_async(task_description, use_llm=True)
            # LLM 分析的质量基于置信度
            quality_score = expert_info.get("llm_analysis", {}).get("confidence", 0.5)
        else:
            # 使用规则引擎
            expert_info = self.generate_expert_prompt(task_description, use_llm=False)
            # Phase 1: 简单质量检查 - 使用模板库，质量设为满分
            quality_score = 1.0

        result = {
            **expert_info,
            "quality_score": quality_score,
            "quality_check_passed": quality_score >= self.server_config.quality_threshold,
        }

        logger.info(
            f"质量检查: {quality_score:.2f} "
            f"({'通过' if result['quality_check_passed'] else '未通过'})"
        )

        return result

    async def generate_expert_prompt_with_meta(
        self,
        user_requirement: str
    ) -> dict:
        """
        使用元提示词生成专家提示词（Phase 2 核心功能）

        这是求知镜的核心功能：
        1. 接收本地AI的原始需求
        2. 使用元提示词（4D流程）生成专家提示词
        3. 返回生成的专家提示词，用于后续会话

        Args:
            user_requirement: 本地AI的原始需求描述

        Returns:
            包含以下字段的字典：
            - expert_prompt: 生成的专家提示词（Markdown格式）
            - task_description: 原始任务描述
            - generation_method: "meta_prompt"（生成方法标识）
            - quality_score: 质量评分
            - timestamp: 生成时间戳
        """
        logger.info(f"使用元提示词生成专家提示词: {len(user_requirement)} 字符")

        try:
            # 构建元提示词请求
            meta_prompt_request = META_PROMPT.format(user_input=user_requirement)

            # 调用LLM生成专家提示词
            response = await self.llm_client.generate(
                prompt=meta_prompt_request,
                response_format="text"  # 元提示词输出Markdown文本
            )

            # 清理响应（移除可能的markdown代码块标记）
            response = response.strip()
            if response.startswith("```markdown"):
                response = response[11:]
            if response.startswith("```"):
                response = response[3:]
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()

            # 记录生成的提示词长度
            prompt_length = len(response)
            logger.info(f"元提示词生成完成: {prompt_length} 字符")

            # 返回结果
            result = {
                "expert_prompt": response,
                "task_description": user_requirement,
                "generation_method": "meta_prompt",
                "quality_score": 1.0,  # 元提示词生成默认高质量
                "timestamp": __import__("datetime").datetime.now().isoformat()
            }

            return result

        except Exception as e:
            logger.error(f"元提示词生成失败: {e}")
            # 回退到规则引擎
            logger.warning("回退到规则引擎模式")
            task_type = self.analyze_task_type(user_requirement)
            expert_info = EXPERT_LIBRARY[task_type]

            # 构建简化版专家提示词
            fallback_prompt = f"""# {expert_info['name']}

## 任务背景
{user_requirement}

## 专家角色设定
{expert_info['system_prompt']}

现在请以{expert_info['name']}的身份，针对上述任务提供专业指导。
"""

            return {
                "expert_prompt": fallback_prompt,
                "task_description": user_requirement,
                "generation_method": "rule_fallback",
                "quality_score": 0.8,
                "timestamp": __import__("datetime").datetime.now().isoformat(),
                "fallback": True,
                "error": str(e)
            }


# 全局实例
_generator: PromptGenerator | None = None


def get_prompt_generator() -> PromptGenerator:
    """获取提示词生成器实例"""
    global _generator
    if _generator is None:
        _generator = PromptGenerator()
    return _generator


def reset_generator():
    """重置生成器（主要用于测试）"""
    global _generator
    _generator = None
