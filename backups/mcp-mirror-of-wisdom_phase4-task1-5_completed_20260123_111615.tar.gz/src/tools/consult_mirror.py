"""start_expert_session 工具实现（Phase 4 重构版）

根据用户指定的专家类型发起专家会话。
用户直接指定专家类型，无需自动识别。

Phase 4 变更：
- 不再返回专家提示词文本
- 创建会话并生成专家首次回复
- 专家提示词作为 system prompt 在求知镜内部使用
"""

import logging
import json
from enum import Enum
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator, ConfigDict
from mcp.server.fastmcp import FastMCP

from mirror_of_wisdom.prompt_generator import EXPERT_LIBRARY, get_prompt_generator
from mirror_of_wisdom.config import get_server_config
from mirror_of_wisdom.session_manager import get_session_manager
from mirror_of_wisdom.llm_client import get_llm_client

logger = logging.getLogger(__name__)


class ResponseFormat(str, Enum):
    """输出格式"""
    MARKDOWN = "markdown"
    JSON = "json"


class ExpertType(str, Enum):
    """专家类型"""
    TECHNICAL = "technical"
    CREATIVE = "creative"
    BUSINESS = "business"
    EDUCATION = "education"
    WRITING = "writing"
    RESEARCH = "research"
    PHILOSOPHY = "philosophy"
    GENERAL = "general"


class StartExpertSessionInput(BaseModel):
    """start_expert_session 工具输入模型（Phase 4 重构版）"""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra='forbid'
    )

    expert_type: ExpertType = Field(
        ...,
        description="专家类型：technical(技术), creative(创意), business(商业), education(教育), writing(写作), research(研究), philosophy(哲学), general(通用)"
    )

    task_description: str = Field(
        ...,
        description="任务描述，说明你需要专家帮助的具体内容",
        min_length=5,
        max_length=2000
    )

    context: Optional[str] = Field(
        default=None,
        description="可选的上下文信息，帮助专家更好地理解你的需求"
    )

    requirements: Optional[str] = Field(
        default=None,
        description="可选的特殊要求或约束条件"
    )

    @field_validator('task_description')
    @classmethod
    def validate_task_description(cls, v: str) -> str:
        """验证任务描述"""
        if not v.strip():
            raise ValueError("任务描述不能为空")
        return v.strip()


def format_expert_prompt(
    expert_type: str,
    task_description: str,
    context: Optional[str] = None,
    requirements: Optional[str] = None
) -> str:
    """
    格式化专家提示词为可读文本

    Args:
        expert_type: 专家类型
        task_description: 任务描述
        context: 可选的上下文信息
        requirements: 可选的特殊要求

    Returns:
        格式化后的提示词文本
    """
    expert_info = EXPERT_LIBRARY[expert_type]

    # 构建内容
    sections = [
        f"# {expert_info['name']}",
        "",
        "## 任务描述",
        task_description,
    ]

    if context:
        sections.extend([
            "",
            "## 背景上下文",
            context,
        ])

    if requirements:
        sections.extend([
            "",
            "## 特殊要求",
            requirements,
        ])

    sections.extend([
        "",
        "## 专家角色设定",
        expert_info['system_prompt'],
        "",
        "---",
        "",
        f"现在请以{expert_info['name']}的身份，针对上述任务提供专业指导。",
    ])

    return "\n".join(sections)


def generate_expert_info(
    expert_type: str,
    task_description: str,
    context: Optional[str] = None,
    requirements: Optional[str] = None
) -> dict:
    """
    生成专家信息字典

    Args:
        expert_type: 专家类型
        task_description: 任务描述
        context: 可选的上下文信息
        requirements: 可选的特殊要求

    Returns:
        包含专家信息的字典
    """
    expert_info = EXPERT_LIBRARY[expert_type]

    result = {
        "expert_type": expert_type,
        "expert_name": expert_info["name"],
        "system_prompt": expert_info["system_prompt"],
        "task_description": task_description,
        "context": context,
        "requirements": requirements,
        "generation_method": "direct",
    }

    return result


async def start_expert_session(params: StartExpertSessionInput) -> str:
    """
    发起专家会话（Phase 4 重构版）

    **功能说明**：
    根据用户指定的专家类型发起专家会话：
    1. 生成专家提示词（内部使用，不返回给本地AI）
    2. 创建会话并存储专家提示词作为 system prompt
    3. 立即生成专家首次回复（信息粒度对齐）
    4. 返回会话ID + 专家首次回复

    **Phase 4 变更**：
    - ❌ 不再返回专家提示词文本
    - ✅ 创建会话并返回首次回复
    - ✅ 专家提示词作为 system prompt 在求知镜内部使用
    - ✅ 零上下文污染

    **使用方法**：
    1. 选择专家类型（expert_type）
    2. 描述任务（task_description）
    3. 可选：提供上下文（context）和要求（requirements）

    Args:
        params: StartExpertSessionInput对象
            - expert_type: 专家类型（必需）
            - task_description: 任务描述（必需）
            - context: 可选上下文
            - requirements: 可选要求

    Returns:
        Markdown格式的响应，包含：
        - 会话ID
        - 专家首次回复（信息粒度对齐问题）
        - 专家类型和质量评分

    Examples:
        >>> result = await start_expert_session(
        ...     StartExpertSessionInput(
        ...         expert_type="technical",
        ...         task_description="优化数据库"
        ...     )
        ... )
        # 返回: 会话ID + 专家首次回复
    """
    try:
        logger.info(
            f"接收到专家会话请求: expert_type={params.expert_type}, "
            f"task_length={len(params.task_description)}"
        )

        # 验证专家类型
        if params.expert_type.value not in EXPERT_LIBRARY:
            return f"**错误**: 不支持的专家类型: {params.expert_type}"

        # 1. 【Phase 4】生成专家提示词（内部，不返回）
        expert_type = params.expert_type.value
        expert_library_entry = EXPERT_LIBRARY[expert_type]

        # 构建完整的专家提示词（包含上下文和要求）
        expert_prompt_parts = [
            expert_library_entry["system_prompt"],
            "",
            "## 任务描述",
            params.task_description
        ]

        if params.context:
            expert_prompt_parts.extend([
                "",
                "## 背景上下文",
                params.context
            ])

        if params.requirements:
            expert_prompt_parts.extend([
                "",
                "## 特殊要求",
                params.requirements
            ])

        expert_prompt = "\n".join(expert_prompt_parts)

        logger.info(f"专家提示词生成成功: type={expert_type}, length={len(expert_prompt)}")

        # 2. 【Phase 4】创建会话
        session_manager = get_session_manager()
        session_id = await session_manager.create_session(
            system_prompt=expert_prompt,
            task_description=params.task_description,
            expert_type=expert_type,
            quality_score=1.0  # 规则引擎模式，质量评分满分
        )

        logger.info(f"会话创建成功: {session_id}")

        # 3. 【Phase 4】生成专家首次回复（信息粒度对齐）
        logger.info("正在生成专家首次回复...")
        llm_client = get_llm_client()

        # 构建用户提示（system prompt 通过参数传递）
        user_prompt = f"用户需求：{params.task_description}\n\n请主动询问细节以对齐信息粒度，然后提供专业指导。"

        # 调用 LLM 生成首次回复
        expert_reply = await llm_client.generate(
            prompt=user_prompt,
            system_prompt=expert_prompt
        )

        logger.info(f"专家首次回复生成成功，长度: {len(expert_reply)} 字符")

        # 4. 【Phase 4】更新会话历史（记录首次对话）
        await session_manager.update_session(
            session_id=session_id,
            user_message=params.task_description,
            assistant_response=expert_reply
        )

        logger.info(f"会话历史已更新: {session_id}")

        # 5. 构建响应（包含专家首次回复）
        expert_name = expert_library_entry["name"]
        response = f"""✅ **专家会话已创建**

**会话ID**: `{session_id}`

**专家类型**: {expert_name}

**任务描述**: {params.task_description[:100]}{'...' if len(params.task_description) > 100 else ''}

**生成方法**: 规则引擎

**质量评分**: 1.00

---

## 📣 专家的首次回复

{expert_reply}

---

## 下一步

使用 `chat_with_expert` 工具继续与专家对话：

```python
chat_with_expert(session_id="{session_id}", message="你的回复")
```

**专家已加载并准备好为您服务。**

---

*求知镜 - Phase 4 架构 | 零上下文污染*
"""

        return response

    except ValueError as e:
        # 输入验证错误
        logger.error(f"输入验证错误: {e}")
        return f"**错误**: {str(e)}\n\n请检查你的输入并重试。"

    except Exception as e:
        # 未预期的错误
        logger.error(f"start_expert_session 执行失败: {e}", exc_info=True)
        return f"""**求知镜暂时无法创建会话**

错误信息: {str(e)}

建议：
1. 检查专家类型是否正确
2. 检查任务描述是否清晰
3. 如果问题持续，请查看日志了解详情

技术细节（用于调试）:
- 错误类型: {type(e).__name__}
- 错误信息: {str(e)}
"""


# 工具 annotations（MCP 最佳实践）
TOOL_ANNOTATIONS = {
    "title": "Start Expert Session",
    "description": "发起专家会话（Phase 4 架构：返回首次回复，零上下文污染）",
    "readOnlyHint": False,      # 创建会话
    "destructiveHint": False,   # 非破坏性
    "idempotentHint": False,   # 重复调用会创建新的专家会话
    "openWorldHint": True      # 与外部 LLM 交互
}
