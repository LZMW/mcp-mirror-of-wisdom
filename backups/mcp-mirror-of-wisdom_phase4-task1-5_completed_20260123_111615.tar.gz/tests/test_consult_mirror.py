"""consult_mirror 工具测试

测试 MCP 工具的完整功能，包括输入验证、输出格式等。
"""

import asyncio
import sys
import os
import json
from pathlib import Path

# Windows UTF-8 编码支持
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# 添加 src 到路径
src_path = Path(__file__).parent.parent / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))

from tools.consult_mirror import consult_mirror, ConsultMirrorInput, ResponseFormat


async def test_consult_mirror_markdown():
    """测试 Markdown 格式输出"""
    print("=" * 60)
    print("测试 1: consult_mirror - Markdown 格式")
    print("=" * 60)

    test_cases = [
        "技术问题：如何优化数据库查询性能？",
        "创意设计：设计一个环保主题的 Logo",
        "商业规划：制定新产品的市场进入策略",
        "通用问题：请帮我整理一份会议纪要",
    ]

    for i, task in enumerate(test_cases, 1):
        print(f"\n【测试 {i}】{task[:40]}...")

        try:
            params = ConsultMirrorInput(
                task_description=task,
                response_format=ResponseFormat.MARKDOWN,
                stage="generate_role"
            )

            result = await consult_mirror(params)

            print(f"✓ 成功 (Markdown)")
            print(f"  - 输出长度: {len(result)} 字符")
            print(f"  - 包含标题: {'是' if '# ' in result else '否'}")

            # 验证必需字段
            assert "# " in result, "缺少标题"
            assert "## 任务描述" in result or "专家角色设定" in result, "缺少必需章节"

        except Exception as e:
            print(f"✗ 失败: {e}")
            import traceback
            traceback.print_exc()

    print("\n" + "=" * 60)


async def test_consult_mirror_json():
    """测试 JSON 格式输出"""
    print("\n测试 2: consult_mirror - JSON 格式")
    print("=" * 60)

    task = "我需要设计一个高并发系统的架构方案"

    try:
        params = ConsultMirrorInput(
            task_description=task,
            response_format=ResponseFormat.JSON,
            stage="generate_role"
        )

        result = await consult_mirror(params)
        data = json.loads(result)

        print(f"✓ 成功 (JSON)")
        print(f"  - task_type: {data.get('task_type')}")
        print(f"  - expert_name: {data.get('expert_name')}")
        print(f"  - generation_method: {data.get('generation_method')}")

        # 验证必需字段
        assert "task_type" in data, "缺少 task_type"
        assert "expert_name" in data, "缺少 expert_name"
        assert "system_prompt" in data, "缺少 system_prompt"
        assert "quality_score" in data, "缺少 quality_score"

        print(f"  - quality_score: {data.get('quality_score')}")

    except Exception as e:
        print(f"✗ 失败: {e}")
        import traceback
        traceback.print_exc()

    print("=" * 60)


async def test_input_validation():
    """测试输入验证"""
    print("\n测试 3: 输入验证")
    print("=" * 60)

    # 测试用例：(描述, 预期是否失败)
    validation_tests = [
        ("太短", True),  # 少于 5 个字符
        ("a" * 2001, True),  # 超过 2000 个字符
        ("这是一个正常的任务描述，长度适中", False),
        ("", True),  # 空字符串
        ("   ", True),  # 只有空格
    ]

    for desc, should_fail in validation_tests:
        print(f"\n测试: '{desc[:30]}...' (预期{'失败' if should_fail else '成功'})")

        try:
            params = ConsultMirrorInput(
                task_description=desc,
                response_format=ResponseFormat.MARKDOWN,
                stage="generate_role"
            )
            if should_fail:
                print(f"✗ 验证失败：应该拒绝但未拒绝")
            else:
                print(f"✓ 验证通过：正常接受")
        except Exception as e:
            if should_fail:
                print(f"✓ 验证通过：正确拒绝 ({type(e).__name__})")
            else:
                print(f"✗ 验证失败：不应该拒绝但拒绝了 ({e})")

    print("\n" + "=" * 60)


async def test_all_expert_types():
    """测试所有 8 种专家类型"""
    print("\n测试 4: 所有专家类型")
    print("=" * 60)

    # 测试用例：每种专家类型的触发关键词
    expert_tests = [
        ("技术专家", "我需要编写 Python 代码来处理 API 请求"),
        ("创意设计师", "帮我设计一个现代风格的网站首页"),
        ("商业战略顾问", "分析电商行业的竞争格局和机会"),
        ("教育专家", "我想学习 Docker 容器技术"),
        ("写作顾问", "帮我写一封专业的求职邮件"),
        ("研究分析师", "收集并分析最新的 AI 市场数据"),
        ("哲学思考者", "探讨人工智能的伦理边界问题"),
        ("通用助手", "你好，请帮我翻译这句话"),
    ]

    results = {}

    for expert_name, task in expert_tests:
        try:
            params = ConsultMirrorInput(
                task_description=task,
                response_format=ResponseFormat.JSON,
                stage="generate_role"
            )

            result_str = await consult_mirror(params)
            result = json.loads(result_str)

            detected_expert = result.get('expert_name')
            results[expert_name] = detected_expert

            status = "✓" if detected_expert == expert_name else "~"
            print(f"{status} {expert_name}: {detected_expert}")

        except Exception as e:
            print(f"✗ {expert_name}: 失败 - {e}")
            results[expert_name] = None

    # 统计
    matched = sum(1 for k, v in results.items() if v == k)
    print(f"\n匹配率: {matched}/{len(results)} ({matched/len(results)*100:.1f}%)")

    print("=" * 60)


async def test_stage_parameter():
    """测试 stage 参数"""
    print("\n测试 5: stage 参数")
    print("=" * 60)

    # 测试 generate_role
    print("\n测试 stage='generate_role'")
    try:
        params = ConsultMirrorInput(
            task_description="这是一个测试任务描述",
            response_format=ResponseFormat.MARKDOWN,
            stage="generate_role"
        )
        result = await consult_mirror(params)
        print(f"✓ 成功，返回 {len(result)} 字符")
    except Exception as e:
        print(f"✗ 失败: {e}")

    # 测试 in_dialogue（Phase 1 暂不支持）
    print("\n测试 stage='in_dialogue' (Phase 1 不支持)")
    try:
        params = ConsultMirrorInput(
            task_description="这是一个测试任务描述",
            response_format=ResponseFormat.MARKDOWN,
            stage="in_dialogue"
        )
        result = await consult_mirror(params)
        if "Phase 2" in result:
            print(f"✓ 正确返回 Phase 2 提示")
        else:
            print(f"~ 返回了内容但不是 Phase 2 提示")
    except Exception as e:
        print(f"✗ 失败: {e}")

    print("\n" + "=" * 60)


async def main():
    """主测试函数"""
    print("\n" + "=" * 60)
    print("consult_mirror 工具完整测试")
    print("=" * 60)

    try:
        await test_consult_mirror_markdown()
        await test_consult_mirror_json()
        await test_input_validation()
        await test_all_expert_types()
        await test_stage_parameter()

        print("\n" + "=" * 60)
        print("✅ 所有测试完成！")
        print("=" * 60)

    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
